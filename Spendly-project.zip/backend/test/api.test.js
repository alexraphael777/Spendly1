import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startServer, tx, today } from './helpers.js';

let s;
before(async () => { s = await startServer(); });
after(async () => { await s.close(); });

test('registration validates input and starts with an empty account', async () => {
  assert.equal((await s.api('POST', '/api/auth/register', { name: 'A', email: 'bad', password: 'Passw0rdX' })).status, 400);
  assert.equal((await s.api('POST', '/api/auth/register', { name: 'A', email: 'a@x.com', password: 'short' })).status, 400);
  assert.equal((await s.api('POST', '/api/auth/register', { name: 'A', email: 'a@x.com', password: 'onlyletters' })).status, 400);
  const a = await s.register('Newbie');
  assert.equal(a.res.status, 201);
  assert.equal((await s.api('POST', '/api/auth/register', { name: 'N', email: 'NEWBIE@test.com', password: 'Passw0rdX' })).status, 409);
  const t = await s.api('GET', '/api/transactions', null, a.token);
  assert.deepEqual([t.body.items.length, t.body.total], [0, 0]);
  assert.equal((await s.api('GET', '/api/budgets', null, a.token)).body.items.length, 0);
  const sum = (await s.api('GET', '/api/reports/summary', null, a.token)).body;
  assert.equal(sum.hasData, false); assert.equal(sum.balance, 0); assert.equal(sum.recent.length, 0); assert.equal(sum.income, 0);
  const n = (await s.api('GET', '/api/notifications', null, a.token)).body;
  assert.equal(n.items.length, 1); assert.equal(n.items[0].type, 'system'); // only the welcome notice, no fake data
  const rep = (await s.api('GET', '/api/reports', null, a.token)).body;
  assert.equal(rep.hasData, false); assert.equal(rep.spendingByCategory.length, 0);
});

test('login, refresh rotation, logout', async () => {
  const a = await s.register('Login');
  assert.equal((await s.api('POST', '/api/auth/login', { email: 'login@test.com', password: 'wrongpass1' })).status, 401);
  assert.equal((await s.api('POST', '/api/auth/login', { email: 'nobody@test.com', password: 'Passw0rdX' })).status, 401);
  const l = await s.api('POST', '/api/auth/login', { email: 'login@test.com', password: 'Passw0rdX' });
  assert.equal(l.status, 200);
  const r1 = await s.api('POST', '/api/auth/refresh', { refreshToken: l.body.refreshToken });
  assert.equal(r1.status, 200);
  assert.equal((await s.api('POST', '/api/auth/refresh', { refreshToken: l.body.refreshToken })).status, 401); // rotated
  assert.equal((await s.api('GET', '/api/me', null, r1.body.accessToken)).status, 200);
  await s.api('POST', '/api/auth/logout', { refreshToken: r1.body.refreshToken });
  assert.equal((await s.api('POST', '/api/auth/refresh', { refreshToken: r1.body.refreshToken })).status, 401);
});

test('protected routes reject missing or forged tokens', async () => {
  for (const p of ['/api/me', '/api/transactions', '/api/budgets', '/api/reports', '/api/notifications', '/api/categories']) {
    assert.equal((await s.api('GET', p)).status, 401, p);
    assert.equal((await s.api('GET', p, null, 'forged.token.value')).status, 401, p);
  }
  assert.equal((await s.api('POST', '/api/ai/chat', { message: 'hi' })).status, 401);
});

test('password reset flow does not reveal accounts and works with the emailed code', async () => {
  await s.register('Reset');
  const unknown = await s.api('POST', '/api/auth/forgot-password', { email: 'ghost@test.com' });
  const known = await s.api('POST', '/api/auth/forgot-password', { email: 'reset@test.com' });
  assert.deepEqual(unknown.body, known.body);
  const code = /(\d{6})/.exec(s.sent.at(-1).text)[1];
  assert.equal((await s.api('POST', '/api/auth/reset-password', { email: 'reset@test.com', code: '000000', newPassword: 'NewPass123' })).status, 400);
  assert.equal((await s.api('POST', '/api/auth/reset-password', { email: 'reset@test.com', code, newPassword: 'NewPass123' })).status, 200);
  assert.equal((await s.api('POST', '/api/auth/login', { email: 'reset@test.com', password: 'NewPass123' })).status, 200);
  assert.equal((await s.api('POST', '/api/auth/reset-password', { email: 'reset@test.com', code, newPassword: 'Another123' })).status, 400); // single use
});

test('google sign-in creates and reuses an account', async () => {
  const a = await s.api('POST', '/api/auth/google', { idToken: 'good-token-123456789012345' });
  assert.equal(a.status, 200);
  const b = await s.api('POST', '/api/auth/google', { idToken: 'good-token-123456789012345' });
  assert.equal(a.body.user.id, b.body.user.id);
  assert.equal((await s.api('POST', '/api/auth/google', { idToken: 'evil-token-123456789012345' })).status, 401);
});

test('USER ISOLATION: one user can never read or change another user\'s data', async () => {
  const a = await s.register('Alice'), b = await s.register('Bob');
  const cat = (await s.api('POST', '/api/categories', { name: 'Alice Secret', type: 'expense' }, a.token)).body;
  const t = (await s.api('POST', '/api/transactions', tx({ amount: 55, categoryId: cat.id, description: 'alice only' }), a.token)).body;
  const bud = (await s.api('POST', '/api/budgets', { categoryId: cat.id, amount: 100, currency: 'USD' }, a.token)).body;
  assert.ok(t.id && bud.id);
  assert.equal((await s.api('GET', '/api/transactions', null, b.token)).body.total, 0);
  assert.equal((await s.api('GET', `/api/transactions/${t.id}`, null, b.token)).status, 404);
  assert.equal((await s.api('PUT', `/api/transactions/${t.id}`, tx({ amount: 1 }), b.token)).status, 404);
  assert.equal((await s.api('DELETE', `/api/transactions/${t.id}`, null, b.token)).status, 404);
  assert.equal((await s.api('POST', '/api/transactions', tx({ categoryId: cat.id }), b.token)).status, 400); // cannot use Alice's category
  assert.equal((await s.api('POST', '/api/budgets', { categoryId: cat.id, amount: 5, currency: 'USD' }, b.token)).status, 400);
  assert.equal((await s.api('PUT', `/api/budgets/${bud.id}`, { amount: 1, currency: 'USD' }, b.token)).status, 404);
  assert.equal((await s.api('DELETE', `/api/budgets/${bud.id}`, null, b.token)).status, 404);
  assert.equal((await s.api('DELETE', `/api/categories/${cat.id}`, null, b.token)).status, 404);
  assert.equal((await s.api('GET', '/api/budgets', null, b.token)).body.items.length, 0);
  assert.equal((await s.api('GET', '/api/categories', null, b.token)).body.items.some((c) => c.id === cat.id), false);
  assert.equal((await s.api('GET', '/api/reports/summary', null, b.token)).body.hasData, false);
  const bn = (await s.api('GET', '/api/notifications', null, b.token)).body.items[0];
  assert.equal((await s.api('DELETE', `/api/notifications/${(await s.api('GET', '/api/notifications', null, a.token)).body.items[0].id}`, null, b.token)).status, 404);
  assert.ok(bn);
  // Alice's data is untouched
  assert.equal((await s.api('GET', `/api/transactions/${t.id}`, null, a.token)).body.amount, 55);
  // a user id in the body or query is ignored
  const r = await s.api('GET', `/api/transactions?userId=${a.user.id}`, null, b.token);
  assert.equal(r.body.total, 0);
});

test('transactions: create, idempotent sync, edit, delete, filters', async () => {
  const u = await s.register('Tx');
  const body = tx({ clientId: 'client-abc-12345', amount: 4500.5, currency: 'NGN', description: 'Jollof lunch' });
  const c1 = await s.api('POST', '/api/transactions', body, u.token);
  const c2 = await s.api('POST', '/api/transactions', body, u.token);
  assert.equal(c1.status, 201); assert.equal(c2.status, 200); assert.equal(c1.body.id, c2.body.id);
  assert.equal(c1.body.amount, 4500.5); assert.equal(c1.body.currency, 'NGN');
  await s.api('POST', '/api/transactions', tx({ type: 'income', categoryId: 'sys_income_salary', amount: 250000, currency: 'NGN', description: 'Salary' }), u.token);
  assert.equal((await s.api('GET', '/api/transactions', null, u.token)).body.total, 2);
  assert.equal((await s.api('GET', '/api/transactions?type=income', null, u.token)).body.total, 1);
  assert.equal((await s.api('GET', '/api/transactions?q=jollof', null, u.token)).body.total, 1);
  assert.equal((await s.api('GET', '/api/transactions?q=100%25', null, u.token)).body.total, 0);
  assert.equal((await s.api('GET', '/api/transactions?categoryId=sys_expense_food', null, u.token)).body.total, 1);
  const upd = await s.api('PUT', `/api/transactions/${c1.body.id}`, tx({ amount: 5000, currency: 'NGN', description: 'Edited' }), u.token);
  assert.equal(upd.body.amount, 5000); assert.equal(upd.body.description, 'Edited');
  assert.equal((await s.api('DELETE', `/api/transactions/${c1.body.id}`, null, u.token)).status, 204);
  assert.equal((await s.api('GET', '/api/transactions', null, u.token)).body.total, 1);
});

test('transaction validation', async () => {
  const u = await s.register('Val');
  for (const bad of [tx({ amount: 0 }), tx({ amount: -5 }), tx({ currency: 'XXX1' }), tx({ currency: 'ZZZ' }), tx({ categoryId: 'nope' }), tx({ type: 'income' }), tx({ occurredAt: 'yesterday' }),
    tx({ occurredAt: new Date(Date.now() + 10 * 86400e3).toISOString() }), tx({ description: 'x'.repeat(300) })]) {
    assert.equal((await s.api('POST', '/api/transactions', bad, u.token)).status, 400, JSON.stringify(bad).slice(0, 80));
  }
});

test('budgets and reports are computed from real transactions with currency conversion', async () => {
  const u = await s.register('Money');
  await s.api('PATCH', '/api/me', { preferredCurrency: 'USD' }, u.token);
  const b = await s.api('POST', '/api/budgets', { categoryId: 'sys_expense_food', amount: 100, currency: 'USD' }, u.token);
  assert.equal(b.status, 201); assert.equal(b.body.spent, 0); assert.equal(b.body.status, 'ok');
  assert.equal((await s.api('POST', '/api/budgets', { categoryId: 'sys_expense_food', amount: 50, currency: 'USD' }, u.token)).status, 409);
  assert.equal((await s.api('POST', '/api/budgets', { categoryId: 'sys_income_salary', amount: 50, currency: 'USD' }, u.token)).status, 400);
  await s.api('POST', '/api/transactions', tx({ amount: 60 }), u.token);
  await s.api('POST', '/api/transactions', tx({ amount: 15000, currency: 'NGN' }), u.token); // 15000 NGN at 1500/USD = 10 USD
  await s.api('POST', '/api/transactions', tx({ categoryId: 'sys_expense_bills', amount: 30 }), u.token);
  await s.api('POST', '/api/transactions', tx({ type: 'income', categoryId: 'sys_income_salary', amount: 500 }), u.token);
  let bud = (await s.api('GET', '/api/budgets', null, u.token)).body;
  assert.equal(bud.items[0].spent, 70); assert.equal(bud.items[0].remaining, 30); assert.equal(bud.items[0].percent, 70); assert.equal(bud.items[0].status, 'ok');
  await s.api('POST', '/api/transactions', tx({ amount: 15 }), u.token);
  bud = (await s.api('GET', '/api/budgets', null, u.token)).body;
  assert.equal(bud.items[0].status, 'warning'); assert.equal(bud.items[0].percent, 85);
  await s.api('POST', '/api/transactions', tx({ amount: 20 }), u.token);
  bud = (await s.api('GET', '/api/budgets', null, u.token)).body;
  assert.equal(bud.items[0].status, 'exceeded'); assert.equal(bud.items[0].remaining, -5);
  const sum = (await s.api('GET', '/api/reports/summary', null, u.token)).body;
  assert.equal(sum.expenses, 135); assert.equal(sum.income, 500); assert.equal(sum.balance, 365);
  assert.equal(sum.categories[0].name, 'Food'); assert.equal(sum.categories[0].amount, 105);
  const rep = (await s.api('GET', '/api/reports', null, u.token)).body;
  assert.equal(rep.summary.net, 365); assert.equal(rep.summary.savingsRate, 73); assert.equal(rep.trend.length, 6);
  assert.equal(rep.spendingByCategory.reduce((a, c) => a + c.percent, 0).toFixed(0), '100');
  assert.equal(rep.premium.unlocked, false); assert.equal(rep.premium.daily, null);
  const n = (await s.api('GET', '/api/notifications?type=alert', null, u.token)).body.items.map((x) => x.title);
  assert.ok(n.some((t) => t.includes('Approaching')) && n.some((t) => t.includes('exceeded')));
  assert.equal((await s.api('PUT', `/api/budgets/${b.body.id}`, { amount: 200, currency: 'USD' }, u.token)).body.status, 'ok');
  assert.equal((await s.api('DELETE', `/api/budgets/${b.body.id}`, null, u.token)).status, 204);
});

test('preferred currency changes report currency (no hardcoded currency)', async () => {
  const u = await s.register('Naira');
  await s.api('PATCH', '/api/me', { preferredCurrency: 'ngn' }, u.token);
  await s.api('POST', '/api/transactions', tx({ amount: 30, currency: 'USD' }), u.token);
  const sum = (await s.api('GET', '/api/reports/summary', null, u.token)).body;
  assert.equal(sum.currency, 'NGN'); assert.equal(sum.expenses, 45000);
  assert.equal((await s.api('PATCH', '/api/me', { preferredCurrency: 'FAKE' }, u.token)).status, 400);
  const cur = (await s.api('GET', '/api/currencies', null, u.token)).body.items;
  for (const c of ['USD', 'NGN', 'GBP', 'EUR', 'CAD', 'AUD']) assert.ok(cur.find((x) => x.code === c), c);
});

test('free vs premium limits are enforced on the server', async () => {
  const u = await s.register('Plan');
  assert.equal((await s.api('GET', '/api/transactions?currency=USD', null, u.token)).status, 402);
  assert.equal((await s.api('GET', `/api/transactions?from=${encodeURIComponent(today())}`, null, u.token)).status, 402);
  for (const n of ['A1', 'B2', 'C3']) assert.equal((await s.api('POST', '/api/categories', { name: n, type: 'expense' }, u.token)).status, 201);
  assert.equal((await s.api('POST', '/api/categories', { name: 'D4', type: 'expense' }, u.token)).status, 402);
  assert.equal((await s.api('POST', '/api/subscription/checkout', {}, u.token)).status, 501); // no fake payment success
  assert.equal((await s.api('GET', '/api/subscription', null, u.token)).body.plan, 'free');
  s.db.prepare("UPDATE subscriptions SET plan = 'premium', status = 'active' WHERE user_id = ?").run(u.user.id);
  assert.equal((await s.api('GET', '/api/transactions?currency=USD', null, u.token)).status, 200);
  assert.equal((await s.api('POST', '/api/categories', { name: 'D4', type: 'expense' }, u.token)).status, 201);
  await s.api('POST', '/api/transactions', tx({ amount: 12 }), u.token);
  const rep = (await s.api('GET', '/api/reports', null, u.token)).body;
  assert.equal(rep.trend.length, 12); assert.equal(rep.premium.topExpenses.length, 1); assert.equal(rep.premium.daily.length, 1);
});

test('account deletion removes all of the user\'s data', async () => {
  const u = await s.register('Gone');
  await s.api('POST', '/api/transactions', tx(), u.token);
  assert.equal((await s.api('DELETE', '/api/me', { confirm: 'DELETE', password: 'wrong' }, u.token)).status, 400);
  assert.equal((await s.api('DELETE', '/api/me', { confirm: 'DELETE', password: 'Passw0rdX' }, u.token)).status, 204);
  assert.equal(s.db.prepare('SELECT COUNT(*) n FROM transactions WHERE user_id = ?').get(u.user.id).n, 0);
  assert.equal((await s.api('GET', '/api/me', null, u.token)).status, 401);
});

test('error responses are safe and consistent', async () => {
  const u = await s.register('Err');
  const r = await s.api('GET', '/api/transactions?limit=9999', null, u.token);
  assert.equal(r.status, 400); assert.equal(r.body.error.code, 'VALIDATION_ERROR');
  assert.equal((await s.api('GET', '/api/nothing', null, u.token)).status, 404);
  assert.ok(!JSON.stringify(r.body).includes('at '));
});
