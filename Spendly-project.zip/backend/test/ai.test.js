import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startServer, tx } from './helpers.js';

const KEY = 'sk-ant-test-key-do-not-leak';
const claude = (text, status = 200) => async (url) => {
  if (String(url).includes('er-api')) return new Response(JSON.stringify({ base_code: 'USD', rates: { USD: 1, NGN: 1500 } }), { status: 200 });
  return new Response(JSON.stringify({ content: [{ type: 'text', text }] }), { status });
};
const anthropicCalls = (s) => s.calls.filter((c) => c.url.includes('api.anthropic.com'));

test('AI: not configured returns 503 only when there is data to discuss', async () => {
  const s = await startServer({ key: '' });
  const u = await s.register('Ai1');
  await s.api('POST', '/api/transactions', tx({ amount: 20 }), u.token);
  const r = await s.api('POST', '/api/ai/chat', { message: 'summary?' }, u.token);
  assert.equal(r.status, 503); assert.equal(r.body.error.code, 'AI_NOT_CONFIGURED');
  await s.close();
});

test('AI: new account gets an honest no-data answer and Claude is never called', async () => {
  const s = await startServer({ key: KEY, fetchImpl: claude('SHOULD NOT BE USED') });
  const u = await s.register('Empty');
  const r = await s.api('POST', '/api/ai/chat', { message: 'How much did I spend on food?' }, u.token);
  assert.equal(r.status, 200); assert.match(r.body.reply, /don't have enough financial data/i);
  assert.equal(anthropicCalls(s).length, 0);
  await s.close();
});

test('AI: Claude receives only this user\'s exact backend numbers and the key stays server side', async () => {
  const s = await startServer({ key: KEY, fetchImpl: claude(`Here you go. Key: ${KEY}`) });
  const a = await s.register('AiA'), b = await s.register('AiB');
  await s.api('POST', '/api/transactions', tx({ amount: 42.5, description: 'ALICE-ONLY-MARKER' }), a.token);
  await s.api('POST', '/api/transactions', tx({ amount: 999, description: 'BOB-ONLY-MARKER' }), b.token);
  const r = await s.api('POST', '/api/ai/chat', { message: 'Where did I spend the most?', history: [{ role: 'assistant', content: 'stale' }, { role: 'user', content: 'hi' }, { role: 'assistant', content: 'hello' }] }, a.token);
  assert.equal(r.status, 200);
  assert.ok(!r.body.reply.includes(KEY)); // output guard
  const call = anthropicCalls(s)[0];
  assert.equal(call.init.headers['x-api-key'], KEY);
  const sent = JSON.parse(call.init.body);
  assert.match(sent.system, /42\.5/); assert.match(sent.system, /ALICE-ONLY-MARKER/);
  assert.ok(!sent.system.includes('BOB-ONLY-MARKER') && !sent.system.includes('999'));
  assert.ok(!sent.system.includes(KEY) && !JSON.stringify(sent.messages).includes(KEY));
  assert.equal(sent.messages[0].role, 'user'); // conversation must start with user
  assert.equal(sent.messages.at(-1).content, 'Where did I spend the most?');
  assert.equal(sent.model, s.config.modelFree);
  assert.match(sent.system, /never invent/i);
  await s.close();
});

test('AI: validation, daily limit, upstream failure', async () => {
  const s = await startServer({ key: KEY, fetchImpl: claude('ok') });
  const u = await s.register('AiV');
  await s.api('POST', '/api/transactions', tx(), u.token);
  assert.equal((await s.api('POST', '/api/ai/chat', { message: '' }, u.token)).status, 400);
  assert.equal((await s.api('POST', '/api/ai/chat', { message: 'x'.repeat(1001) }, u.token)).status, 400);
  assert.equal((await s.api('POST', '/api/ai/chat', { message: 'hi', history: Array(11).fill({ role: 'user', content: 'a' }) }, u.token)).status, 400);
  s.db.prepare("INSERT INTO ai_usage (user_id, day, count) VALUES (?, ?, 10)").run(u.user.id, new Date().toISOString().slice(0, 10));
  const lim = await s.api('POST', '/api/ai/chat', { message: 'hi' }, u.token);
  assert.equal(lim.status, 429); assert.equal(lim.body.error.code, 'AI_DAILY_LIMIT');
  await s.close();
  const s2 = await startServer({ key: KEY, fetchImpl: claude('x', 401) });
  const u2 = await s2.register('AiF');
  await s2.api('POST', '/api/transactions', tx(), u2.token);
  const bad = await s2.api('POST', '/api/ai/chat', { message: 'hi' }, u2.token);
  assert.equal(bad.status, 502); assert.ok(!JSON.stringify(bad.body).includes(KEY));
  await s2.close();
});

test('AI: premium users get the premium model', async () => {
  const s = await startServer({ key: KEY, fetchImpl: claude('deep analysis') });
  const u = await s.register('AiP');
  s.db.prepare("UPDATE subscriptions SET plan = 'premium' WHERE user_id = ?").run(u.user.id);
  await s.api('POST', '/api/transactions', tx(), u.token);
  await s.api('POST', '/api/ai/chat', { message: 'hi' }, u.token);
  assert.equal(JSON.parse(anthropicCalls(s)[0].init.body).model, s.config.modelPremium);
  await s.close();
});
