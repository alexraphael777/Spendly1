import { openDb } from '../src/db.js';
import { createApp } from '../src/app.js';
import { loadConfig } from '../src/config.js';

export async function startServer(opts = {}) {
  const config = { ...loadConfig({}), bcryptRounds: 4, anthropicKey: opts.key ?? '', limits: { global: 100000, auth: 100000 } };
  const db = openDb(':memory:');
  const calls = [];
  const fetchImpl = opts.fetchImpl || (async (url, init) => {
    calls.push({ url, init });
    if (String(url).includes('er-api')) return new Response(JSON.stringify({ base_code: 'USD', rates: { USD: 1, NGN: 1500, EUR: 0.9, GBP: 0.8 } }), { status: 200 });
    return new Response('{}', { status: 500 });
  });
  const sent = [];
  const app = createApp({ db, config, fetchImpl: (u, i) => { calls.push({ url: String(u), init: i }); return fetchImpl(u, i); }, sendMail: async (m) => { sent.push(m); },
    verifyGoogle: async (t) => { if (t.startsWith('good')) return { sub: 'g-' + t, email: `${t}@gmail.com`, email_verified: true, name: 'G User' }; throw new Error('bad'); } });
  const server = await new Promise((r) => { const s = app.listen(0, () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const api = async (method, path, body, token) => {
    const res = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  };
  const register = async (n, em = `${n.toLowerCase()}@test.com`) => {
    const r = await api('POST', '/api/auth/register', { name: n, email: em, password: 'Passw0rdX' });
    return { token: r.body.accessToken, refresh: r.body.refreshToken, user: r.body.user, res: r };
  };
  return { api, register, db, calls, sent, config, close: () => new Promise((r) => { server.close(r); }) };
}
export const today = () => new Date().toISOString();
export const tx = (o = {}) => ({ type: 'expense', amount: 10, currency: 'USD', categoryId: 'sys_expense_food', description: 'Lunch', occurredAt: today(), ...o });
