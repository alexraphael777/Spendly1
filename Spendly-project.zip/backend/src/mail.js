export function createMailer({ config, fetchImpl }) {
  return async function sendMail({ to, subject, text }) {
    if (config.resendKey) {
      const res = await fetchImpl('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: config.mailFrom, to, subject, text }),
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) throw new Error(`mail provider status ${res.status}`);
      return;
    }
    if (!config.prod) { console.log(`[dev mail] to=${to} subject=${subject}\n${text}`); return; }
    console.warn('Email provider not configured (set RESEND_API_KEY). Password reset email not sent.');
  };
}
