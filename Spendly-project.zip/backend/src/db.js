import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT, google_sub TEXT UNIQUE, avatar_url TEXT,
  preferred_currency TEXT NOT NULL DEFAULT 'USD', notif_prefs TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS subscriptions (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  plan TEXT NOT NULL DEFAULT 'free', status TEXT NOT NULL DEFAULT 'active',
  provider TEXT, provider_ref TEXT, current_period_end TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_refresh_user ON refresh_tokens(user_id);
CREATE TABLE IF NOT EXISTS reset_codes (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL, expires_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, type TEXT NOT NULL CHECK (type IN ('expense','income')),
  icon TEXT NOT NULL DEFAULT 'other', color TEXT NOT NULL DEFAULT '#6B7280', created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_categories_user ON categories(user_id);
CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id TEXT, type TEXT NOT NULL CHECK (type IN ('expense','income')),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0), currency TEXT NOT NULL,
  category_id TEXT NOT NULL REFERENCES categories(id),
  description TEXT NOT NULL DEFAULT '', payment_method TEXT,
  occurred_at TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE (user_id, client_id));
CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_tx_user_cat ON transactions(user_id, category_id);
CREATE TABLE IF NOT EXISTS budgets (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id TEXT NOT NULL REFERENCES categories(id), amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL, period TEXT NOT NULL DEFAULT 'monthly', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE (user_id, category_id, period));
CREATE TABLE IF NOT EXISTS exchange_rates (
  base TEXT NOT NULL, target TEXT NOT NULL, rate REAL NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY (base, target));
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('alert','transaction','insight','system')),
  title TEXT NOT NULL, message TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0,
  dedupe_key TEXT, created_at TEXT NOT NULL, UNIQUE (user_id, dedupe_key));
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, created_at);
CREATE TABLE IF NOT EXISTS ai_usage (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, day TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day));
`;

// Standard categories every user can pick from. These are not user data.
const STANDARD = [
  ['expense', 'Food', 'food', '#F59E0B'], ['expense', 'Transport', 'transport', '#2F80ED'],
  ['expense', 'Bills', 'bills', '#EF4444'], ['expense', 'Shopping', 'shopping', '#8B5CF6'],
  ['expense', 'Education', 'education', '#6366F1'], ['expense', 'Health', 'health', '#EC4899'],
  ['expense', 'Entertainment', 'entertainment', '#14B8A6'], ['expense', 'Other', 'other', '#6B7280'],
  ['income', 'Salary', 'salary', '#16A34A'], ['income', 'Freelance', 'freelance', '#22C55E'],
  ['income', 'Business', 'business', '#0EA5E9'], ['income', 'Gift', 'gift', '#F97316'],
  ['income', 'Other Income', 'other', '#6B7280'],
];

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  const ins = db.prepare('INSERT OR IGNORE INTO categories (id, user_id, name, type, icon, color, created_at) VALUES (?, NULL, ?, ?, ?, ?, ?)');
  for (const [type, name, icon, color] of STANDARD) ins.run(`sys_${type}_${icon}${name === 'Other Income' ? '_income' : ''}`, name, type, icon, color, new Date().toISOString());
  return db;
}
