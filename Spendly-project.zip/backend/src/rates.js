export function createRates({ db, fetchImpl, url }) {
  let lastAttempt = 0;
  async function refresh() {
    const row = db.prepare('SELECT MAX(updated_at) m FROM exchange_rates').get();
    if (row.m && Date.now() - Date.parse(row.m) < 12 * 3600e3) return;
    if (Date.now() - lastAttempt < 60e3) return;
    lastAttempt = Date.now();
    try {
      const res = await fetchImpl(url, { signal: AbortSignal.timeout(8000) });
      if (!res.ok) throw new Error(`rates http ${res.status}`);
      const json = await res.json();
      const base = json.base_code || 'USD';
      if (!json.rates || typeof json.rates !== 'object') throw new Error('bad rates payload');
      const now = new Date().toISOString();
      const up = db.prepare('INSERT OR REPLACE INTO exchange_rates (base, target, rate, updated_at) VALUES (?, ?, ?, ?)');
      db.exec('BEGIN');
      try {
        for (const [code, rate] of Object.entries(json.rates)) if (Number.isFinite(rate) && rate > 0) up.run(base, code, rate, now);
        up.run(base, base, 1, now);
        db.exec('COMMIT');
      } catch (e) { db.exec('ROLLBACK'); throw e; }
    } catch (e) {
      console.warn('exchange rate refresh failed:', e.message); // keep serving stored rates
    }
  }
  const table = () => {
    const t = {};
    for (const r of db.prepare("SELECT target, rate FROM exchange_rates WHERE base = 'USD'").all()) t[r.target] = r.rate;
    t.USD = 1;
    return t;
  };
  const convert = (t, amount, from, to) => {
    if (from === to) return amount;
    const r = t[to] / t[from];
    return Number.isFinite(r) ? amount * r : null;
  };
  const meta = () => db.prepare("SELECT MAX(updated_at) updatedAt FROM exchange_rates WHERE base = 'USD'").get().updatedAt || null;
  return { refresh, table, convert, meta };
}
