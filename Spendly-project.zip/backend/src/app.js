import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z, ZodError } from 'zod';
import { createHash, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { OAuth2Client } from 'google-auth-library';
import { ApiError, newId, iso, isCurrency, listCurrencies, toMinor, toMajor, currentMonth } from './util.js';
import { createRates } from './rates.js';
import { createMailer } from './mail.js';
import { TX_SELECT, txOut, monthBounds, budgetStatuses, buildSummary, buildReport, notify, parsePrefs, runAlerts } from './finance.js';
import { SYSTEM_PROMPT, buildAiContext, toClaudeMessages, askClaude } from './ai.js';

const LIMITS = {
  free: { customCategories: 3, budgets: 5, aiMessagesPerDay: 10, trendMonths: 6, advancedFilters: false, advancedReports: false },
  premium: { customCategories: null, budgets: null, aiMessagesPerDay: 100, trendMonths: 12, advancedFilters: true, advancedReports: true },
};
const sha = (s) => createHash('sha256').update(s).digest('hex');
const email = z.string().trim().toLowerCase().email().max(254);
const password = z.string().min(8, 'Password must be at least 8 characters').max(128)
  .refine((p) => /[A-Za-z]/.test(p) && /\d/.test(p), 'Password must contain a letter and a number');
const currency = z.string().length(3).transform((s) => s.toUpperCase()).refine(isCurrency, 'Unsupported currency');
const monthStr = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/);
const name = z.string().trim().min(1).max(80);
const PAY = ['cash', 'card', 'bank_transfer', 'mobile_money', 'other'];
const txBody = z.object({
  clientId: z.string().min(8).max(64).optional(), type: z.enum(['expense', 'income']),
  amount: z.number().positive().max(1e12), currency, categoryId: z.string().min(1).max(64),
  description: z.string().trim().max(200).optional().default(''),
  paymentMethod: z.enum(PAY).nullable().optional(), occurredAt: z.string().datetime({ offset: true }),
});
const budgetBody = z.object({ categoryId: z.string().min(1).max(64), amount: z.number().positive().max(1e12), currency });

export function createApp({ db, config, fetchImpl = fetch, verifyGoogle, sendMail }) {
  const app = express();
  const rates = createRates({ db, fetchImpl, url: config.ratesUrl });
  const mail = sendMail || createMailer({ config, fetchImpl });
  const googleClient = new OAuth2Client();
  const checkGoogle = verifyGoogle || (async (idToken) => {
    if (!config.googleClientIds.length) throw new ApiError(503, 'GOOGLE_NOT_CONFIGURED', 'Google sign-in is not configured.');
    const t = await googleClient.verifyIdToken({ idToken, audience: config.googleClientIds });
    return t.getPayload();
  });

  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', config.trustProxy);
  app.use(helmet());
  app.use(express.json({ limit: '50kb' }));
  app.use((req, res, next) => {
    const t = Date.now();
    res.on('finish', () => { if (req.path !== '/health') console.log(`${req.method} ${req.path} ${res.statusCode} ${Date.now() - t}ms`); });
    next();
  });
  const limiter = (windowMs, limit, keyGenerator) => rateLimit({
    windowMs, limit, standardHeaders: true, legacyHeaders: false, keyGenerator, validate: false,
    handler: (req, res) => res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Too many requests. Please try again shortly.' } }),
  });
  app.get('/health', (req, res) => res.json({ status: 'ok' }));
  app.use('/api', limiter(60_000, config.limits.global));
  const authLimiter = limiter(15 * 60_000, config.limits.auth);
  const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

  // ---------- helpers ----------
  const tzOf = (req) => { const v = Number(req.query.tz ?? req.get('x-tz-offset') ?? 0); return Number.isInteger(v) && Math.abs(v) <= 840 ? v : 0; };
  const isPremium = (userId) => {
    const s = db.prepare('SELECT * FROM subscriptions WHERE user_id = ?').get(userId);
    return !!s && s.plan === 'premium' && s.status === 'active' && (!s.current_period_end || Date.parse(s.current_period_end) > Date.now());
  };
  const subOut = (userId) => {
    const s = db.prepare('SELECT * FROM subscriptions WHERE user_id = ?').get(userId);
    const premium = isPremium(userId);
    return { plan: premium ? 'premium' : 'free', status: s?.status || 'active', currentPeriodEnd: s?.current_period_end || null, limits: premium ? LIMITS.premium : LIMITS.free };
  };
  const userOut = (u) => ({
    id: u.id, name: u.name, email: u.email, avatarUrl: u.avatar_url, preferredCurrency: u.preferred_currency,
    notificationPrefs: parsePrefs(u.notif_prefs), hasPassword: !!u.password_hash, createdAt: u.created_at, subscription: subOut(u.id),
  });
  const needPremium = (userId, what) => { if (!isPremium(userId)) throw new ApiError(402, 'PREMIUM_REQUIRED', `${what} is a Premium feature.`); };
  const mkctx = async () => { await rates.refresh(); return { db, rates, table: rates.table() }; };
  const q = (schema, req) => schema.parse(req.query);

  function issueTokens(user) {
    const accessToken = jwt.sign({ sub: user.id }, config.jwtSecret, { expiresIn: config.accessTtlSeconds, issuer: 'spendly' });
    const refreshToken = randomBytes(48).toString('base64url');
    const exp = new Date(Date.now() + config.refreshTtlDays * 86400e3).toISOString();
    db.prepare('INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at, revoked, created_at) VALUES (?, ?, ?, ?, 0, ?)').run(newId(), user.id, sha(refreshToken), exp, iso());
    return { accessToken, refreshToken, expiresIn: config.accessTtlSeconds };
  }
  const authResponse = (user) => ({ ...issueTokens(user), user: userOut(user) });
  function createUser({ nameV, emailV, passwordHash = null, googleSub = null, avatar = null }) {
    const id = newId(), now = iso();
    db.prepare('INSERT INTO users (id, name, email, password_hash, google_sub, avatar_url, preferred_currency, notif_prefs, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(id, nameV, emailV, passwordHash, googleSub, avatar, 'USD', '{}', now, now);
    db.prepare('INSERT INTO subscriptions (user_id, plan, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)').run(id, 'free', 'active', now, now);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    notify(db, user, null, { type: 'system', title: 'Welcome to Spendly', message: 'Know where your money goes. Add your first transaction to get started.', dedupeKey: 'welcome' });
    return user;
  }
  const requireAuth = (req, res, next) => {
    const m = /^Bearer (.+)$/.exec(req.get('authorization') || '');
    if (!m) return next(new ApiError(401, 'UNAUTHENTICATED', 'Please sign in.'));
    try {
      const payload = jwt.verify(m[1], config.jwtSecret, { issuer: 'spendly' });
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
      if (!user) return next(new ApiError(401, 'UNAUTHENTICATED', 'Please sign in.'));
      req.user = user;
      return next();
    } catch { return next(new ApiError(401, 'UNAUTHENTICATED', 'Your session has expired. Please sign in again.')); }
  };
  const getCategory = (userId, id, type) => {
    const c = db.prepare('SELECT * FROM categories WHERE id = ? AND (user_id IS NULL OR user_id = ?)').get(id, userId);
    if (!c) throw new ApiError(400, 'INVALID_CATEGORY', 'That category does not exist.');
    if (type && c.type !== type) throw new ApiError(400, 'INVALID_CATEGORY', `Category "${c.name}" is not a ${type} category.`);
    return c;
  };
  const dummyHash = bcrypt.hashSync('not-a-real-password', 4);

  // ---------- auth ----------
  app.post('/api/auth/register', authLimiter, h(async (req, res) => {
    const b = z.object({ name, email, password }).parse(req.body);
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(b.email)) throw new ApiError(409, 'EMAIL_TAKEN', 'An account with this email already exists.');
    const user = createUser({ nameV: b.name, emailV: b.email, passwordHash: await bcrypt.hash(b.password, config.bcryptRounds) });
    res.status(201).json(authResponse(user));
  }));
  app.post('/api/auth/login', authLimiter, h(async (req, res) => {
    const b = z.object({ email, password: z.string().min(1).max(128) }).parse(req.body);
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(b.email);
    const ok = await bcrypt.compare(b.password, user?.password_hash || dummyHash);
    if (!user || !user.password_hash || !ok) throw new ApiError(401, 'INVALID_CREDENTIALS', 'Incorrect email or password.');
    res.json(authResponse(user));
  }));
  app.post('/api/auth/google', authLimiter, h(async (req, res) => {
    const { idToken } = z.object({ idToken: z.string().min(20).max(4096) }).parse(req.body);
    let p;
    try { p = await checkGoogle(idToken); } catch (e) { if (e instanceof ApiError) throw e; throw new ApiError(401, 'INVALID_GOOGLE_TOKEN', 'Google sign-in failed. Please try again.'); }
    if (!p?.sub || !p.email || p.email_verified === false) throw new ApiError(401, 'INVALID_GOOGLE_TOKEN', 'Google sign-in failed. Please try again.');
    const em = p.email.toLowerCase();
    let user = db.prepare('SELECT * FROM users WHERE google_sub = ?').get(p.sub);
    if (!user) {
      const byEmail = db.prepare('SELECT * FROM users WHERE email = ?').get(em);
      if (byEmail) { db.prepare('UPDATE users SET google_sub = ?, avatar_url = COALESCE(avatar_url, ?), updated_at = ? WHERE id = ?').run(p.sub, p.picture || null, iso(), byEmail.id); user = db.prepare('SELECT * FROM users WHERE id = ?').get(byEmail.id); }
      else user = createUser({ nameV: (p.name || em.split('@')[0]).slice(0, 80), emailV: em, googleSub: p.sub, avatar: p.picture || null });
    }
    res.json(authResponse(user));
  }));
  app.post('/api/auth/refresh', authLimiter, h((req, res) => {
    const { refreshToken } = z.object({ refreshToken: z.string().min(20).max(200) }).parse(req.body);
    const row = db.prepare('SELECT * FROM refresh_tokens WHERE token_hash = ?').get(sha(refreshToken));
    if (!row || row.revoked || Date.parse(row.expires_at) < Date.now()) throw new ApiError(401, 'UNAUTHENTICATED', 'Your session has expired. Please sign in again.');
    db.prepare('UPDATE refresh_tokens SET revoked = 1 WHERE id = ?').run(row.id);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id);
    res.json(issueTokens(user));
  }));
  app.post('/api/auth/logout', h((req, res) => {
    const { refreshToken } = z.object({ refreshToken: z.string().max(200) }).parse(req.body);
    db.prepare('UPDATE refresh_tokens SET revoked = 1 WHERE token_hash = ?').run(sha(refreshToken));
    res.status(204).end();
  }));
  app.post('/api/auth/forgot-password', authLimiter, h(async (req, res) => {
    const b = z.object({ email }).parse(req.body);
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(b.email);
    if (user) {
      const code = String(randomInt(0, 1000000)).padStart(6, '0');
      db.prepare('INSERT OR REPLACE INTO reset_codes (user_id, code_hash, expires_at, attempts) VALUES (?, ?, ?, 0)').run(user.id, sha(code), new Date(Date.now() + 15 * 60e3).toISOString());
      try { await mail({ to: user.email, subject: 'Your Spendly password reset code', text: `Your Spendly reset code is ${code}. It expires in 15 minutes. If you did not request this, you can ignore this email.` }); }
      catch (e) { console.warn('reset email failed:', e.message); }
    }
    res.json({ message: 'If an account exists for that email, a reset code has been sent.' }); // same reply either way
  }));
  app.post('/api/auth/reset-password', authLimiter, h(async (req, res) => {
    const b = z.object({ email, code: z.string().regex(/^\d{6}$/), newPassword: password }).parse(req.body);
    const bad = new ApiError(400, 'INVALID_CODE', 'That code is invalid or has expired.');
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(b.email);
    if (!user) throw bad;
    const rc = db.prepare('SELECT * FROM reset_codes WHERE user_id = ?').get(user.id);
    if (!rc || rc.attempts >= 5 || Date.parse(rc.expires_at) < Date.now()) throw bad;
    const a = Buffer.from(sha(b.code)), c = Buffer.from(rc.code_hash);
    if (a.length !== c.length || !timingSafeEqual(a, c)) { db.prepare('UPDATE reset_codes SET attempts = attempts + 1 WHERE user_id = ?').run(user.id); throw bad; }
    db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(await bcrypt.hash(b.newPassword, config.bcryptRounds), iso(), user.id);
    db.prepare('DELETE FROM reset_codes WHERE user_id = ?').run(user.id);
    db.prepare('UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?').run(user.id);
    notify(db, user, null, { type: 'system', title: 'Password changed', message: 'Your password was reset. If this was not you, contact support.' });
    res.json({ message: 'Password updated. You can now sign in.' });
  }));

  // ---------- profile ----------
  app.get('/api/me', requireAuth, (req, res) => res.json(userOut(req.user)));
  app.patch('/api/me', requireAuth, h((req, res) => {
    const b = z.object({
      name: name.optional(), preferredCurrency: currency.optional(),
      notificationPrefs: z.object({ budgetAlerts: z.boolean(), insights: z.boolean(), transactions: z.boolean() }).partial().optional(),
    }).parse(req.body);
    const prefs = { ...parsePrefs(req.user.notif_prefs), ...(b.notificationPrefs || {}) };
    db.prepare('UPDATE users SET name = ?, preferred_currency = ?, notif_prefs = ?, updated_at = ? WHERE id = ?')
      .run(b.name ?? req.user.name, b.preferredCurrency ?? req.user.preferred_currency, JSON.stringify(prefs), iso(), req.user.id);
    res.json(userOut(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)));
  }));
  app.post('/api/me/password', requireAuth, authLimiter, h(async (req, res) => {
    const b = z.object({ currentPassword: z.string().max(128).optional(), newPassword: password }).parse(req.body);
    if (req.user.password_hash && !(await bcrypt.compare(b.currentPassword || '', req.user.password_hash))) throw new ApiError(400, 'INVALID_CREDENTIALS', 'Your current password is incorrect.');
    db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(await bcrypt.hash(b.newPassword, config.bcryptRounds), iso(), req.user.id);
    db.prepare('UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?').run(req.user.id);
    res.json({ ...issueTokens(req.user) });
  }));
  app.delete('/api/me', requireAuth, h(async (req, res) => {
    const b = z.object({ confirm: z.literal('DELETE'), password: z.string().max(128).optional() }).parse(req.body);
    if (req.user.password_hash && !(await bcrypt.compare(b.password || '', req.user.password_hash))) throw new ApiError(400, 'INVALID_CREDENTIALS', 'Your password is incorrect.');
    db.prepare('DELETE FROM users WHERE id = ?').run(req.user.id); // cascades to all of the user's data
    res.status(204).end();
  }));

  // ---------- currencies ----------
  const currencyList = listCurrencies();
  app.get('/api/currencies', requireAuth, (req, res) => res.json({ items: currencyList }));
  app.get('/api/exchange-rates', requireAuth, h(async (req, res) => {
    const { base } = z.object({ base: currency.default('USD') }).parse(req.query);
    const ctx = await mkctx();
    const out = {};
    for (const code of Object.keys(ctx.table)) { const v = rates.convert(ctx.table, 1, base, code); if (v != null) out[code] = v; }
    res.json({ base, updatedAt: rates.meta(), rates: out });
  }));

  // ---------- categories ----------
  app.get('/api/categories', requireAuth, (req, res) => {
    const rows = db.prepare('SELECT * FROM categories WHERE user_id IS NULL OR user_id = ? ORDER BY type, user_id IS NOT NULL, name').all(req.user.id);
    res.json({ items: rows.map((c) => ({ id: c.id, name: c.name, type: c.type, icon: c.icon, color: c.color, custom: !!c.user_id })) });
  });
  app.post('/api/categories', requireAuth, h((req, res) => {
    const b = z.object({ name, type: z.enum(['expense', 'income']), icon: z.string().max(30).default('other'), color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).default('#6B7280') }).parse(req.body);
    const lim = subOut(req.user.id).limits.customCategories;
    const n = db.prepare('SELECT COUNT(*) n FROM categories WHERE user_id = ?').get(req.user.id).n;
    if (lim != null && n >= lim) throw new ApiError(402, 'PREMIUM_REQUIRED', `Free accounts can create up to ${lim} custom categories. Upgrade for unlimited.`);
    if (db.prepare('SELECT 1 FROM categories WHERE (user_id IS NULL OR user_id = ?) AND type = ? AND name = ? COLLATE NOCASE').get(req.user.id, b.type, b.name)) throw new ApiError(409, 'CATEGORY_EXISTS', 'A category with that name already exists.');
    const id = newId();
    db.prepare('INSERT INTO categories (id, user_id, name, type, icon, color, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(id, req.user.id, b.name, b.type, b.icon, b.color, iso());
    res.status(201).json({ id, name: b.name, type: b.type, icon: b.icon, color: b.color, custom: true });
  }));
  app.delete('/api/categories/:id', requireAuth, h((req, res) => {
    const c = db.prepare('SELECT * FROM categories WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
    if (!c) throw new ApiError(404, 'NOT_FOUND', 'Category not found.');
    if (db.prepare('SELECT 1 FROM transactions WHERE category_id = ? LIMIT 1').get(c.id) || db.prepare('SELECT 1 FROM budgets WHERE category_id = ? LIMIT 1').get(c.id))
      throw new ApiError(409, 'CATEGORY_IN_USE', 'This category is used by transactions or budgets.');
    db.prepare('DELETE FROM categories WHERE id = ?').run(c.id);
    res.status(204).end();
  }));

  // ---------- transactions ----------
  const listQuery = z.object({
    q: z.string().trim().max(100).optional(), type: z.enum(['expense', 'income']).optional(), categoryId: z.string().max(64).optional(),
    month: monthStr.optional(), from: z.string().datetime({ offset: true }).optional(), to: z.string().datetime({ offset: true }).optional(),
    currency: currency.optional(), limit: z.coerce.number().int().min(1).max(100).default(50), offset: z.coerce.number().int().min(0).default(0),
  });
  app.get('/api/transactions', requireAuth, h((req, res) => {
    const f = q(listQuery, req), uid = req.user.id;
    const where = ['t.user_id = ?'], args = [uid];
    if (f.from || f.to || f.currency) needPremium(uid, 'Advanced filters');
    if (f.q) { where.push("(t.description LIKE ? ESCAPE '\\' OR c.name LIKE ? ESCAPE '\\')"); const l = `%${f.q.replace(/[\\%_]/g, '\\$&')}%`; args.push(l, l); }
    if (f.type) { where.push('t.type = ?'); args.push(f.type); }
    if (f.categoryId) { where.push('t.category_id = ?'); args.push(f.categoryId); }
    if (f.currency) { where.push('t.currency = ?'); args.push(f.currency); }
    if (f.month) { const [s, e] = monthBounds(f.month, tzOf(req)); where.push('t.occurred_at >= ? AND t.occurred_at < ?'); args.push(s, e); }
    if (f.from) { where.push('t.occurred_at >= ?'); args.push(new Date(f.from).toISOString()); }
    if (f.to) { where.push('t.occurred_at <= ?'); args.push(new Date(f.to).toISOString()); }
    const w = where.join(' AND ');
    const total = db.prepare(`SELECT COUNT(*) n FROM transactions t JOIN categories c ON c.id = t.category_id WHERE ${w}`).get(...args).n;
    const rows = db.prepare(`${TX_SELECT} WHERE ${w} ORDER BY t.occurred_at DESC, t.created_at DESC LIMIT ? OFFSET ?`).all(...args, f.limit, f.offset);
    res.json({ items: rows.map(txOut), total, limit: f.limit, offset: f.offset });
  }));
  const getTx = (uid, id) => db.prepare(`${TX_SELECT} WHERE t.id = ? AND t.user_id = ?`).get(id, uid);
  const checkDate = (s) => { if (Date.parse(s) > Date.now() + 86400e3) throw new ApiError(400, 'VALIDATION_ERROR', 'Date cannot be in the future.'); };
  app.get('/api/transactions/:id', requireAuth, h((req, res) => {
    const r = getTx(req.user.id, req.params.id);
    if (!r) throw new ApiError(404, 'NOT_FOUND', 'Transaction not found.');
    res.json(txOut(r));
  }));
  app.post('/api/transactions', requireAuth, h(async (req, res) => {
    const b = txBody.parse(req.body), u = req.user;
    if (b.clientId) { const ex = db.prepare(`${TX_SELECT} WHERE t.user_id = ? AND t.client_id = ?`).get(u.id, b.clientId); if (ex) return res.status(200).json(txOut(ex)); }
    getCategory(u.id, b.categoryId, b.type);
    checkDate(b.occurredAt);
    const minor = toMinor(b.amount, b.currency);
    if (minor < 1) throw new ApiError(400, 'VALIDATION_ERROR', 'Amount is too small.');
    const id = newId(), now = iso(), occurred = new Date(b.occurredAt).toISOString();
    db.prepare('INSERT INTO transactions (id, user_id, client_id, type, amount_minor, currency, category_id, description, payment_method, occurred_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(id, u.id, b.clientId ?? null, b.type, minor, b.currency, b.categoryId, b.description, b.paymentMethod ?? null, occurred, now, now);
    const row = getTx(u.id, id);
    runAlerts(await mkctx(), u, row, tzOf(req));
    res.status(201).json(txOut(row));
  }));
  app.put('/api/transactions/:id', requireAuth, h(async (req, res) => {
    const b = txBody.omit({ clientId: true }).parse(req.body), u = req.user;
    if (!getTx(u.id, req.params.id)) throw new ApiError(404, 'NOT_FOUND', 'Transaction not found.');
    getCategory(u.id, b.categoryId, b.type);
    checkDate(b.occurredAt);
    const minor = toMinor(b.amount, b.currency);
    if (minor < 1) throw new ApiError(400, 'VALIDATION_ERROR', 'Amount is too small.');
    db.prepare('UPDATE transactions SET type = ?, amount_minor = ?, currency = ?, category_id = ?, description = ?, payment_method = ?, occurred_at = ?, updated_at = ? WHERE id = ? AND user_id = ?')
      .run(b.type, minor, b.currency, b.categoryId, b.description, b.paymentMethod ?? null, new Date(b.occurredAt).toISOString(), iso(), req.params.id, u.id);
    const row = getTx(u.id, req.params.id);
    runAlerts(await mkctx(), u, row, tzOf(req));
    res.json(txOut(row));
  }));
  app.delete('/api/transactions/:id', requireAuth, h((req, res) => {
    const r = db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    if (!r.changes) throw new ApiError(404, 'NOT_FOUND', 'Transaction not found.');
    res.status(204).end();
  }));

  // ---------- budgets ----------
  app.get('/api/budgets', requireAuth, h(async (req, res) => {
    const { month } = q(z.object({ month: monthStr.default(currentMonth(tzOf(req))) }), req);
    const items = budgetStatuses(await mkctx(), req.user.id, month, tzOf(req));
    const cur = req.user.preferred_currency, ctx = { rates, table: rates.table() };
    let limit = 0, spent = 0;
    for (const b of items) { const l = rates.convert(ctx.table, b.amount, b.currency, cur), s = rates.convert(ctx.table, b.spent, b.currency, cur); if (l != null && s != null) { limit += l; spent += s; } }
    const dec = (n) => Math.round(n * 100) / 100;
    res.json({ month, currency: cur, items, totals: { limit: dec(limit), spent: dec(spent), remaining: dec(limit - spent), percent: limit > 0 ? Math.round((spent / limit) * 100) : 0 } });
  }));
  const budgetItem = async (req, id) => budgetStatuses(await mkctx(), req.user.id, currentMonth(tzOf(req)), tzOf(req)).find((b) => b.id === id);
  app.post('/api/budgets', requireAuth, h(async (req, res) => {
    const b = budgetBody.parse(req.body), u = req.user;
    getCategory(u.id, b.categoryId, 'expense');
    const lim = subOut(u.id).limits.budgets;
    if (lim != null && db.prepare('SELECT COUNT(*) n FROM budgets WHERE user_id = ?').get(u.id).n >= lim) throw new ApiError(402, 'PREMIUM_REQUIRED', `Free accounts can have up to ${lim} budgets. Upgrade for unlimited.`);
    if (db.prepare("SELECT 1 FROM budgets WHERE user_id = ? AND category_id = ? AND period = 'monthly'").get(u.id, b.categoryId)) throw new ApiError(409, 'BUDGET_EXISTS', 'You already have a budget for this category.');
    const id = newId(), now = iso();
    db.prepare("INSERT INTO budgets (id, user_id, category_id, amount_minor, currency, period, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'monthly', ?, ?)").run(id, u.id, b.categoryId, toMinor(b.amount, b.currency), b.currency, now, now);
    res.status(201).json(await budgetItem(req, id));
  }));
  app.put('/api/budgets/:id', requireAuth, h(async (req, res) => {
    const b = budgetBody.omit({ categoryId: true }).parse(req.body);
    const r = db.prepare('UPDATE budgets SET amount_minor = ?, currency = ?, updated_at = ? WHERE id = ? AND user_id = ?').run(toMinor(b.amount, b.currency), b.currency, iso(), req.params.id, req.user.id);
    if (!r.changes) throw new ApiError(404, 'NOT_FOUND', 'Budget not found.');
    res.json(await budgetItem(req, req.params.id));
  }));
  app.delete('/api/budgets/:id', requireAuth, h((req, res) => {
    const r = db.prepare('DELETE FROM budgets WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    if (!r.changes) throw new ApiError(404, 'NOT_FOUND', 'Budget not found.');
    res.status(204).end();
  }));

  // ---------- reports ----------
  const monthQ = (req) => q(z.object({ month: monthStr.default(currentMonth(tzOf(req))) }), req).month;
  app.get('/api/reports/summary', requireAuth, h(async (req, res) => res.json(buildSummary(await mkctx(), req.user, monthQ(req), tzOf(req)))));
  app.get('/api/reports', requireAuth, h(async (req, res) => res.json(buildReport(await mkctx(), req.user, monthQ(req), tzOf(req), isPremium(req.user.id)))));

  // ---------- notifications ----------
  const nOut = (n) => ({ id: n.id, type: n.type, title: n.title, message: n.message, read: !!n.read, createdAt: n.created_at });
  app.get('/api/notifications', requireAuth, h((req, res) => {
    const { type } = q(z.object({ type: z.enum(['alert', 'transaction', 'insight', 'system']).optional() }), req);
    const rows = type ? db.prepare('SELECT * FROM notifications WHERE user_id = ? AND type = ? ORDER BY created_at DESC LIMIT 100').all(req.user.id, type)
      : db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100').all(req.user.id);
    res.json({ items: rows.map(nOut), unreadCount: db.prepare('SELECT COUNT(*) n FROM notifications WHERE user_id = ? AND read = 0').get(req.user.id).n });
  }));
  app.post('/api/notifications/read-all', requireAuth, (req, res) => { db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(req.user.id); res.status(204).end(); });
  app.patch('/api/notifications/:id/read', requireAuth, h((req, res) => {
    const r = db.prepare('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    if (!r.changes) throw new ApiError(404, 'NOT_FOUND', 'Notification not found.');
    res.status(204).end();
  }));
  app.delete('/api/notifications/:id', requireAuth, h((req, res) => {
    const r = db.prepare('DELETE FROM notifications WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    if (!r.changes) throw new ApiError(404, 'NOT_FOUND', 'Notification not found.');
    res.status(204).end();
  }));

  // ---------- subscription ----------
  app.get('/api/subscription', requireAuth, (req, res) => res.json({ ...subOut(req.user.id), paymentsConfigured: false, plans: { free: LIMITS.free, premium: LIMITS.premium } }));
  app.post('/api/subscription/checkout', requireAuth, (req, res) => {
    // No payment provider is connected yet. Premium is only ever granted by a verified provider webhook.
    res.status(501).json({ error: { code: 'PAYMENTS_NOT_CONFIGURED', message: 'Premium purchases are not available yet.' } });
  });

  // ---------- AI assistant ----------
  const aiLimiter = limiter(60_000, 12, (req) => req.user?.id || req.ip);
  const aiBody = z.object({
    message: z.string().trim().min(1).max(1000),
    history: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().max(3000) })).max(10).default([]),
  });
  app.post('/api/ai/chat', requireAuth, aiLimiter, h(async (req, res) => {
    const b = aiBody.parse(req.body), u = req.user, premium = isPremium(u.id);
    const day = new Date().toISOString().slice(0, 10), cap = premium ? LIMITS.premium.aiMessagesPerDay : LIMITS.free.aiMessagesPerDay;
    const used = db.prepare('SELECT count FROM ai_usage WHERE user_id = ? AND day = ?').get(u.id, day)?.count || 0;
    if (used >= cap) throw new ApiError(429, 'AI_DAILY_LIMIT', `You have reached today's limit of ${cap} assistant messages.${premium ? '' : ' Upgrade to Premium for more.'}`);
    const ctx = await mkctx();
    const { hasAnyData, context } = buildAiContext(ctx, u, premium, tzOf(req));
    const remaining = cap - used - 1;
    if (!hasAnyData) {
      return res.json({ reply: "I don't have enough financial data to answer yet. Add a few transactions or create a budget, and I'll be able to summarize your spending and give tips.", remainingToday: cap - used });
    }
    db.prepare('INSERT INTO ai_usage (user_id, day, count) VALUES (?, ?, 1) ON CONFLICT(user_id, day) DO UPDATE SET count = count + 1').run(u.id, day);
    const reply = await askClaude({
      config, fetchImpl, model: premium ? config.modelPremium : config.modelFree,
      system: `${SYSTEM_PROMPT}\n\n<financial_data>\n${JSON.stringify(context)}\n</financial_data>`,
      messages: toClaudeMessages(b.history, b.message),
    });
    res.json({ reply, remainingToday: remaining });
  }));

  // ---------- errors ----------
  app.use('/api', (req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Not found.' } }));
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    if (err instanceof ApiError) return res.status(err.status).json({ error: { code: err.code, message: err.message, details: err.details } });
    if (err instanceof ZodError) return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: err.issues[0]?.message || 'Invalid request.', details: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })) } });
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Invalid JSON.' } });
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: { code: 'PAYLOAD_TOO_LARGE', message: 'Request too large.' } });
    console.error('unhandled error:', err?.message);
    return res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Something went wrong. Please try again.' } });
  });
  return app;
}
