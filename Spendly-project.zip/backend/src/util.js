import { randomUUID } from 'node:crypto';

export class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}
export const newId = () => randomUUID();
export const iso = () => new Date().toISOString();

const CURRENCIES = new Set(Intl.supportedValuesOf('currency'));
export const isCurrency = (c) => CURRENCIES.has(c);
const decCache = new Map();
export function decimalsOf(c) {
  if (!decCache.has(c)) decCache.set(c, new Intl.NumberFormat('en', { style: 'currency', currency: c }).resolvedOptions().maximumFractionDigits);
  return decCache.get(c);
}
export const toMinor = (a, c) => Math.round(a * 10 ** decimalsOf(c));
export const toMajor = (m, c) => m / 10 ** decimalsOf(c);
export const roundTo = (n, c) => { const f = 10 ** decimalsOf(c); return Math.round(n * f) / f; };
export const fmtMoney = (n, c) => new Intl.NumberFormat('en', { style: 'currency', currency: c }).format(n);
export function listCurrencies() {
  const names = new Intl.DisplayNames(['en'], { type: 'currency' });
  return [...CURRENCIES].sort().map((code) => ({
    code,
    name: names.of(code) || code,
    symbol: new Intl.NumberFormat('en', { style: 'currency', currency: code, currencyDisplay: 'narrowSymbol' }).formatToParts(0).find((p) => p.type === 'currency')?.value || code,
    decimals: decimalsOf(code),
  }));
}

// Month helpers. tz = minutes ahead of UTC (Nigeria = 60).
export function monthRange(month, tz = 0) {
  const [y, m] = month.split('-').map(Number);
  return {
    start: new Date(Date.UTC(y, m - 1, 1) - tz * 60000).toISOString(),
    end: new Date(Date.UTC(y, m, 1) - tz * 60000).toISOString(),
  };
}
export const currentMonth = (tz = 0) => new Date(Date.now() + tz * 60000).toISOString().slice(0, 7);
export const monthOf = (instant, tz = 0) => new Date(Date.parse(instant) + tz * 60000).toISOString().slice(0, 7);
export function shiftMonth(month, delta) {
  const [y, m] = month.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1 + delta, 1)).toISOString().slice(0, 7);
}
export const daysInMonth = (month) => { const [y, m] = month.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).getUTCDate(); };
