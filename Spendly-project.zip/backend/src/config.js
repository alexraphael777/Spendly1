export function loadConfig(env = process.env) {
  const prod = env.NODE_ENV === 'production';
  const jwtSecret = env.JWT_SECRET || '';
  if (prod && jwtSecret.length < 32) throw new Error('JWT_SECRET (32+ characters) is required in production');
  return {
    prod,
    port: Number(env.PORT || 3000),
    dbPath: env.DATABASE_PATH || './data/spendly.db',
    jwtSecret: jwtSecret || 'development-only-secret-do-not-use-in-production',
    accessTtlSeconds: 15 * 60,
    refreshTtlDays: 30,
    bcryptRounds: 11,
    trustProxy: env.TRUST_PROXY ? Number(env.TRUST_PROXY) : 0,
    googleClientIds: (env.GOOGLE_CLIENT_IDS || '').split(',').map((s) => s.trim()).filter(Boolean),
    anthropicKey: env.ANTHROPIC_API_KEY || '',
    modelFree: env.ANTHROPIC_MODEL_FREE || 'claude-haiku-4-5-20251001',
    modelPremium: env.ANTHROPIC_MODEL_PREMIUM || 'claude-sonnet-5-5',
    ratesUrl: env.RATES_URL || 'https://open.er-api.com/v6/latest/USD',
    resendKey: env.RESEND_API_KEY || '',
    mailFrom: env.MAIL_FROM || 'Spendly <no-reply@example.com>',
    limits: { global: 300, auth: 30 },
  };
}
