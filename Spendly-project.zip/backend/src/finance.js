// Deterministic financial calculations. The backend is the source of truth for every number.
import { toMajor, roundTo, monthRange, shiftMonth, currentMonth, daysInMonth, fmtMoney, monthOf } from './util.js';

export const TX_SELECT = `SELECT t.*, c.id AS cid, c.name AS cname, c.icon AS cicon, c.color AS ccolor
  FROM transactions t JOIN categories c ON c.id = t.category_id`;

export const txOut = (r) => ({
  id: r.id, clientId: r.client_id, type: r.type, amount: toMajor(r.amount_minor, r.currency), currency: r.currency,
  category: { id: r.cid, name: r.cname, icon: r.cicon, color: r.ccolor, type: r.type },
  description: r.description || '', paymentMethod: r.payment_method || null,
  occurredAt: r.occurred_at, createdAt: r.created_at, updatedAt: r.updated_at,
});

const ALL = ['0000-01-01T00:00:00.000Z', '9999-01-01T00:00:00.000Z'];
export const monthBounds = (month, tz) => { const r = monthRange(month, tz); return [r.start, r.end]; };

export function aggregate(ctx, userId, range, target) {
  const { db, rates, table } = ctx;
  const rows = db.prepare(`SELECT t.type, t.currency, t.category_id cid, c.name cname, c.icon cicon, c.color ccolor,
      SUM(t.amount_minor) s, COUNT(*) n
    FROM transactions t JOIN categories c ON c.id = t.category_id
    WHERE t.user_id = ? AND t.occurred_at >= ? AND t.occurred_at < ?
    GROUP BY t.type, t.currency, t.category_id`).all(userId, range[0], range[1]);
  let income = 0, expenses = 0, count = 0, unconverted = 0;
  const cats = new Map();
  for (const r of rows) {
    count += r.n;
    const v = rates.convert(table, toMajor(r.s, r.currency), r.currency, target);
    if (v == null) { unconverted += r.n; continue; }
    if (r.type === 'income') income += v;
    else {
      expenses += v;
      const c = cats.get(r.cid) || { id: r.cid, name: r.cname, icon: r.cicon, color: r.ccolor, amount: 0 };
      c.amount += v;
      cats.set(r.cid, c);
    }
  }
  const byCategory = [...cats.values()]
    .map((c) => ({ ...c, percent: expenses > 0 ? Math.round((c.amount / expenses) * 1000) / 10 : 0, amount: roundTo(c.amount, target) }))
    .sort((a, b) => b.amount - a.amount);
  return { income: roundTo(income, target), expenses: roundTo(expenses, target), net: roundTo(income - expenses, target), count, unconverted, byCategory };
}

export function budgetStatuses(ctx, userId, month, tz) {
  const { db, rates, table } = ctx;
  const [start, end] = monthBounds(month, tz);
  const budgets = db.prepare(`SELECT b.*, c.name cname, c.icon cicon, c.color ccolor FROM budgets b
    JOIN categories c ON c.id = b.category_id WHERE b.user_id = ? ORDER BY c.name`).all(userId);
  const sums = db.prepare(`SELECT currency, SUM(amount_minor) s FROM transactions
    WHERE user_id = ? AND category_id = ? AND type = 'expense' AND occurred_at >= ? AND occurred_at < ? GROUP BY currency`);
  return budgets.map((b) => {
    let spent = 0, unconverted = 0;
    for (const r of sums.all(userId, b.category_id, start, end)) {
      const v = rates.convert(table, toMajor(r.s, r.currency), r.currency, b.currency);
      if (v == null) unconverted++; else spent += v;
    }
    spent = roundTo(spent, b.currency);
    const amount = toMajor(b.amount_minor, b.currency);
    const percent = Math.round((spent / amount) * 100);
    return {
      id: b.id, category: { id: b.category_id, name: b.cname, icon: b.cicon, color: b.ccolor, type: 'expense' },
      amount, currency: b.currency, period: b.period, spent, remaining: roundTo(amount - spent, b.currency),
      percent, status: percent >= 100 ? 'exceeded' : percent >= 80 ? 'warning' : 'ok', unconverted,
      createdAt: b.created_at, updatedAt: b.updated_at,
    };
  });
}

function insightsFor(m, p, budgets, cur) {
  const out = [];
  if (p.expenses > 0 && m.expenses > 0) {
    const ch = Math.round(((m.expenses - p.expenses) / p.expenses) * 100);
    if (ch >= 10) out.push({ kind: 'warning', text: `You have spent ${ch}% more than last month (${fmtMoney(m.expenses, cur)} vs ${fmtMoney(p.expenses, cur)}).` });
    else if (ch <= -10) out.push({ kind: 'positive', text: `You have spent ${Math.abs(ch)}% less than last month. Nice work.` });
  }
  if (m.byCategory[0]) out.push({ kind: 'info', text: `${m.byCategory[0].name} is your biggest expense this month (${m.byCategory[0].percent}% of spending).` });
  for (const c of m.byCategory) {
    const prev = p.byCategory.find((x) => x.id === c.id);
    if (prev && prev.amount > 0 && c.amount >= prev.amount * 1.2) {
      out.push({ kind: 'warning', text: `You spent ${Math.round(((c.amount - prev.amount) / prev.amount) * 100)}% more on ${c.name} than last month.` });
      break;
    }
  }
  for (const b of budgets) {
    if (b.status === 'exceeded') out.push({ kind: 'warning', text: `You are over your ${b.category.name} budget by ${fmtMoney(-b.remaining, b.currency)}.` });
    else if (b.status === 'warning') out.push({ kind: 'warning', text: `You are approaching your ${b.category.name} budget (${b.percent}% used).` });
  }
  return out.slice(0, 5);
}

export function buildSummary(ctx, user, month, tz) {
  const cur = user.preferred_currency;
  const all = aggregate(ctx, user.id, ALL, cur);
  const m = aggregate(ctx, user.id, monthBounds(month, tz), cur);
  const p = aggregate(ctx, user.id, monthBounds(shiftMonth(month, -1), tz), cur);
  const budgets = budgetStatuses(ctx, user.id, month, tz);
  let limit = 0, spent = 0;
  for (const b of budgets) {
    const l = ctx.rates.convert(ctx.table, b.amount, b.currency, cur), s = ctx.rates.convert(ctx.table, b.spent, b.currency, cur);
    if (l != null && s != null) { limit += l; spent += s; }
  }
  let progress = null;
  if (limit > 0) progress = { basis: 'budget', limit: roundTo(limit, cur), spent: roundTo(spent, cur), percent: Math.round((spent / limit) * 100) };
  else if (m.income > 0) progress = { basis: 'income', limit: m.income, spent: m.expenses, percent: Math.round((m.expenses / m.income) * 100) };
  const recent = ctx.db.prepare(`${TX_SELECT} WHERE t.user_id = ? ORDER BY t.occurred_at DESC, t.created_at DESC LIMIT 5`).all(user.id).map(txOut);
  return {
    month, currency: cur, hasData: all.count > 0 || budgets.length > 0,
    balance: all.net, income: m.income, expenses: m.expenses, previousExpenses: p.expenses,
    progress, categories: m.byCategory.slice(0, 5), recent, insights: insightsFor(m, p, budgets, cur),
    unconvertedCount: all.unconverted, ratesUpdatedAt: ctx.rates.meta(),
  };
}

export function buildReport(ctx, user, month, tz, premium) {
  const cur = user.preferred_currency;
  const range = monthBounds(month, tz);
  const m = aggregate(ctx, user.id, range, cur);
  const months = premium ? 12 : 6;
  const trend = [];
  for (let i = months - 1; i >= 0; i--) {
    const mm = shiftMonth(month, -i);
    const a = aggregate(ctx, user.id, monthBounds(mm, tz), cur);
    trend.push({ month: mm, income: a.income, expenses: a.expenses });
  }
  const elapsed = month === currentMonth(tz) ? new Date(Date.now() + tz * 60000).getUTCDate() : daysInMonth(month);
  const report = {
    month, currency: cur, hasData: m.count > 0 || trend.some((t) => t.income || t.expenses),
    summary: {
      income: m.income, expenses: m.expenses, net: m.net, transactionCount: m.count,
      savingsRate: m.income > 0 ? Math.round((m.net / m.income) * 100) : null,
      averageDailySpend: roundTo(m.expenses / elapsed, cur),
    },
    spendingByCategory: m.byCategory, trend, budgetPerformance: budgetStatuses(ctx, user.id, month, tz),
    unconvertedCount: m.unconverted, premium: { unlocked: premium, trendMonths: months, daily: null, topExpenses: null },
  };
  if (premium) {
    const rows = ctx.db.prepare(`${TX_SELECT} WHERE t.user_id = ? AND t.type = 'expense' AND t.occurred_at >= ? AND t.occurred_at < ?`).all(user.id, range[0], range[1]);
    const daily = new Map();
    const conv = [];
    for (const r of rows) {
      const v = ctx.rates.convert(ctx.table, toMajor(r.amount_minor, r.currency), r.currency, cur);
      if (v == null) continue;
      const day = new Date(Date.parse(r.occurred_at) + tz * 60000).toISOString().slice(0, 10);
      daily.set(day, (daily.get(day) || 0) + v);
      conv.push({ tx: txOut(r), converted: roundTo(v, cur) });
    }
    report.premium.daily = [...daily.entries()].sort().map(([date, amount]) => ({ date, amount: roundTo(amount, cur) }));
    report.premium.topExpenses = conv.sort((a, b) => b.converted - a.converted).slice(0, 5).map((x) => ({ ...x.tx, convertedAmount: x.converted }));
  }
  return report;
}

export function notify(db, user, prefKey, { type, title, message, dedupeKey }) {
  const prefs = parsePrefs(user.notif_prefs);
  if (prefKey && prefs[prefKey] === false) return;
  db.prepare('INSERT OR IGNORE INTO notifications (id, user_id, type, title, message, read, dedupe_key, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?)')
    .run(crypto.randomUUID(), user.id, type, title, message, dedupeKey || null, new Date().toISOString());
}
export const DEFAULT_PREFS = { budgetAlerts: true, insights: true, transactions: true };
export const parsePrefs = (s) => { try { return { ...DEFAULT_PREFS, ...JSON.parse(s || '{}') }; } catch { return { ...DEFAULT_PREFS }; } };

// Called after a transaction is saved. Generates budget alerts and insight notifications.
export function runAlerts(ctx, user, tx, tz) {
  const { db } = ctx;
  const month = monthOf(tx.occurred_at, tz);
  const total = db.prepare('SELECT COUNT(*) n FROM transactions WHERE user_id = ?').get(user.id).n;
  if (total === 1) notify(db, user, 'transactions', { type: 'transaction', title: 'First transaction recorded', message: 'Nice start! Keep adding transactions to unlock reports and insights.', dedupeKey: 'first-tx' });
  if (tx.type !== 'expense') return;
  const b = budgetStatuses(ctx, user.id, month, tz).find((x) => x.category.id === tx.category_id);
  if (b && b.percent >= 80) {
    const over = b.percent >= 100;
    notify(db, user, 'budgetAlerts', {
      type: 'alert', dedupeKey: `budget:${b.id}:${month}:${over ? 100 : 80}`,
      title: over ? `${b.category.name} budget exceeded` : `Approaching ${b.category.name} budget`,
      message: over ? `You have spent ${fmtMoney(b.spent, b.currency)} of your ${fmtMoney(b.amount, b.currency)} ${b.category.name} budget for ${month}.`
        : `You have used ${b.percent}% of your ${b.category.name} budget for ${month}.`,
    });
  }
  const cur = user.preferred_currency;
  const now = aggregate(ctx, user.id, monthBounds(month, tz), cur).byCategory.find((c) => c.id === tx.category_id);
  const prev = aggregate(ctx, user.id, monthBounds(shiftMonth(month, -1), tz), cur).byCategory.find((c) => c.id === tx.category_id);
  if (now && prev && prev.amount > 0 && now.amount >= prev.amount * 1.3) {
    notify(db, user, 'insights', {
      type: 'insight', dedupeKey: `insight:${tx.category_id}:${month}`, title: `${now.name} spending is up`,
      message: `You have spent ${Math.round(((now.amount - prev.amount) / prev.amount) * 100)}% more on ${now.name} than last month.`,
    });
  }
}
