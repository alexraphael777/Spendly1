import { loadConfig } from './config.js';
import { openDb } from './db.js';
import { createApp } from './app.js';

const config = loadConfig();
const db = openDb(config.dbPath);
const app = createApp({ db, config });
app.listen(config.port, () => console.log(`Spendly API listening on :${config.port} (ai: ${config.anthropicKey ? 'configured' : 'NOT configured'})`));
