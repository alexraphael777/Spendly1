package com.spendly.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Receipt
import com.spendly.app.ui.components.EmptyState
import com.spendly.app.ui.components.ErrorState
import com.spendly.app.ui.theme.SpendlyTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class StatesTest {
    @get:Rule val rule = createComposeRule()

    @Test fun emptyStateShowsMessageAndAction() {
        var clicked = false
        rule.setContent { SpendlyTheme { EmptyState(Icons.Filled.Receipt, "No transactions yet.", "Your transactions will appear here.", actionLabel = "Add transaction", onAction = { clicked = true }) } }
        rule.onNodeWithText("No transactions yet.").assertIsDisplayed()
        rule.onNodeWithText("Add transaction").performClick()
        assertTrue(clicked)
    }

    @Test fun errorStateOffersRetry() {
        var retried = false
        rule.setContent { SpendlyTheme { ErrorState("You appear to be offline.", onRetry = { retried = true }) } }
        rule.onNodeWithText("Try again").performClick()
        assertTrue(retried)
    }
}
