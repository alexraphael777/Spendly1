package com.spendly.app

import android.app.Application
import android.content.Context
import com.spendly.app.data.ConnectivityMonitor
import com.spendly.app.data.LocalCache
import com.spendly.app.data.Network
import com.spendly.app.data.SessionStore
import com.spendly.app.data.SpendlyRepository
import kotlinx.serialization.json.Json

class AppContainer(context: Context) {
    val json = Json { ignoreUnknownKeys = true; explicitNulls = false; encodeDefaults = true }
    val session = SessionStore(context)
    val cache = LocalCache(context)
    val repo = SpendlyRepository(Network.create(BuildConfig.API_BASE_URL, session, json), session, cache, json)
    val connectivity = ConnectivityMonitor(context)
    val prefs = context.getSharedPreferences("spendly_prefs", Context.MODE_PRIVATE)
}

class SpendlyApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(applicationContext)
    }
}
