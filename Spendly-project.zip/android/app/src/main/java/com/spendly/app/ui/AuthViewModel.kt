package com.spendly.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spendly.app.AppContainer
import com.spendly.app.core.Money
import com.spendly.app.data.AppError
import com.spendly.app.data.UpdateMeRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface Boot {
    data object Loading : Boot
    data object SignedIn : Boot
    data class SignedOut(val onboarded: Boolean) : Boot
}

object AuthValidation {
    private val emailRe = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")
    fun email(v: String): String? = if (emailRe.matches(v.trim())) null else "Enter a valid email address"
    fun password(v: String): String? = when {
        v.length < 8 -> "Use at least 8 characters"
        !v.any { it.isLetter() } || !v.any { it.isDigit() } -> "Include a letter and a number"
        else -> null
    }
    fun name(v: String): String? = if (v.trim().isEmpty()) "Enter your name" else null
}

class AuthViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.repo
    private val _boot = MutableStateFlow<Boot>(Boot.Loading)
    val boot: StateFlow<Boot> = _boot

    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var info by mutableStateOf<String?>(null); private set
    var resetSent by mutableStateOf(false); private set

    init { start() }

    private fun start() = viewModelScope.launch {
        val onboarded = c.prefs.getBoolean("onboarded", false)
        if (!repo.hasSession) { _boot.value = Boot.SignedOut(onboarded); return@launch }
        repo.me().fold(
            onSuccess = { _boot.value = Boot.SignedIn },
            onFailure = { e ->
                val err = e as? AppError
                _boot.value = when {
                    err?.status == 401 -> { repo.clearLocal(); Boot.SignedOut(onboarded) }
                    repo.cachedUser() != null -> Boot.SignedIn // offline: open with cached data
                    else -> Boot.SignedOut(onboarded)
                }
            },
        )
    }

    fun markSignedIn() { _boot.value = Boot.SignedIn }
    fun markSignedOut() { _boot.value = Boot.SignedOut(true); clearMessages(); resetSent = false }

    fun finishOnboarding() { c.prefs.edit().putBoolean("onboarded", true).apply() }
    fun clearMessages() { error = null; info = null }

    fun signIn(email: String, password: String, onDone: () -> Unit) {
        AuthValidation.email(email)?.let { error = it; return }
        if (password.isEmpty()) { error = "Enter your password"; return }
        run(onDone) { repo.signIn(email, password) }
    }

    fun signUp(name: String, email: String, password: String, confirm: String, currency: String, onDone: () -> Unit) {
        (AuthValidation.name(name) ?: AuthValidation.email(email) ?: AuthValidation.password(password))?.let { error = it; return }
        if (password != confirm) { error = "Passwords do not match"; return }
        busy = true; error = null
        viewModelScope.launch {
            repo.signUp(name, email, password).fold(
                onSuccess = {
                    if (currency != it.preferredCurrency) repo.updateMe(UpdateMeRequest(preferredCurrency = currency))
                    busy = false; onDone()
                },
                onFailure = { busy = false; error = it.message },
            )
        }
    }

    fun googleSignedIn(idToken: String, onDone: () -> Unit) = run(onDone) { repo.signInWithGoogle(idToken) }
    fun googleFailed(message: String) { error = message }

    fun requestReset(email: String) {
        AuthValidation.email(email)?.let { error = it; return }
        busy = true; error = null
        viewModelScope.launch {
            repo.requestPasswordReset(email).fold(
                onSuccess = { busy = false; resetSent = true; info = "If an account exists for that email, we sent a 6-digit code." },
                onFailure = { busy = false; error = it.message },
            )
        }
    }

    fun resetPassword(email: String, code: String, newPassword: String, onDone: () -> Unit) {
        if (code.trim().length != 6) { error = "Enter the 6-digit code"; return }
        AuthValidation.password(newPassword)?.let { error = it; return }
        busy = true; error = null
        viewModelScope.launch {
            repo.resetPassword(email, code, newPassword).fold(
                onSuccess = { busy = false; resetSent = false; onDone() },
                onFailure = { busy = false; error = it.message },
            )
        }
    }

    private fun <T> run(onDone: () -> Unit, block: suspend () -> Result<T>) {
        busy = true; error = null
        viewModelScope.launch {
            block().fold(onSuccess = { busy = false; onDone() }, onFailure = { busy = false; error = it.message })
        }
    }

    val defaultCurrency: String get() = Money.defaultCurrency()
}
