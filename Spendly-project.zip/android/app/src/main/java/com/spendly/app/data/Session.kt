package com.spendly.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/** Tokens live in Android Keystore backed encrypted preferences. Nothing sensitive is hardcoded. */
class SessionStore(private val context: Context) {
    private val prefs: SharedPreferences = open()
    private val _signedIn = MutableStateFlow(prefs.getString(REFRESH, null) != null)
    val signedIn: StateFlow<Boolean> = _signedIn

    val accessToken: String? get() = prefs.getString(ACCESS, null)
    val refreshToken: String? get() = prefs.getString(REFRESH, null)
    val hasSession: Boolean get() = refreshToken != null

    @Synchronized fun save(access: String, refresh: String) {
        prefs.edit().putString(ACCESS, access).putString(REFRESH, refresh).apply()
        _signedIn.value = true
    }

    @Synchronized fun clear() {
        prefs.edit().remove(ACCESS).remove(REFRESH).apply()
        _signedIn.value = false
    }

    private fun open(): SharedPreferences = try {
        create()
    } catch (e: Exception) {
        // Keystore data can become unreadable after a restore or OS reset. Start clean rather than crash.
        context.deleteSharedPreferences(FILE)
        create()
    }

    private fun create(): SharedPreferences {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            context, FILE, key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    private companion object {
        const val FILE = "spendly_secure"
        const val ACCESS = "access"
        const val REFRESH = "refresh"
    }
}

/** Small JSON file cache in app-private, non-backed-up storage. Cleared on sign out. */
class LocalCache(context: Context) {
    private val dir = File(context.noBackupFilesDir, "cache").apply { mkdirs() }
    private fun file(key: String) = File(dir, key.replace(Regex("[^A-Za-z0-9_.-]"), "_") + ".json")

    @Synchronized fun read(key: String): String? = runCatching { file(key).takeIf { it.exists() }?.readText() }.getOrNull()
    @Synchronized fun write(key: String, text: String) { runCatching { file(key).writeText(text) } }
    @Synchronized fun remove(key: String) { runCatching { file(key).delete() } }
    @Synchronized fun clearAll() { dir.listFiles()?.forEach { it.delete() } }
}
