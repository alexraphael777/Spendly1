package com.spendly.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.spendly.app.core.Dates
import com.spendly.app.core.Money
import com.spendly.app.data.TransactionRequest
import com.spendly.app.ui.AppViewModel
import com.spendly.app.ui.components.*
import java.time.LocalDate

private val PAYMENT = listOf("cash" to "Cash", "card" to "Card", "bank_transfer" to "Bank transfer", "mobile_money" to "Mobile money", "other" to "Other")

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionScreen(vm: AppViewModel, editId: String?, initialType: String, onClose: () -> Unit, onUpgrade: () -> Unit) {
    val editing = remember(editId) { editId?.let { vm.findTransaction(it) } }
    var type by rememberSaveable { mutableStateOf(editing?.type ?: initialType) }
    var amountText by rememberSaveable { mutableStateOf(editing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var currency by rememberSaveable { mutableStateOf(editing?.currency ?: vm.preferredCurrency) }
    var categoryId by rememberSaveable { mutableStateOf(editing?.category?.id) }
    var dateStr by rememberSaveable { mutableStateOf((editing?.let { Dates.localDate(it.occurredAt) } ?: LocalDate.now()).toString()) }
    var payment by rememberSaveable { mutableStateOf(editing?.paymentMethod) }
    var note by rememberSaveable { mutableStateOf(editing?.description ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var pickDate by remember { mutableStateOf(false) }
    var pickCurrency by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf(false) }
    val date = LocalDate.parse(dateStr)
    val cats = vm.categories.filter { it.type == type }

    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(if (editing != null) "Edit Transaction" else "Add Transaction", onBack = onClose)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            if (editId != null && editing == null) {
                EmptyState(Icons.Filled.SearchOff, "Transaction not found", "It may have been deleted.", actionLabel = "Go back", onAction = onClose)
                return@Column
            }
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("expense" to "Expense", "income" to "Income").forEachIndexed { i, (key, label) ->
                    SegmentedButton(
                        selected = type == key, onClick = { if (type != key) { type = key; categoryId = null } },
                        shape = SegmentedButtonDefaults.itemShape(i, 2), label = { Text(label) },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SpendlyTextField(
                    amountText, { v -> amountText = v.filter { it.isDigit() || it == '.' || it == ',' }.take(16); error = null }, "Amount",
                    Modifier.weight(1f), keyboardType = KeyboardType.Decimal, prefix = Money.symbol(currency) + " ",
                )
                Spacer(Modifier.width(8.dp))
                CurrencyChip(currency, { pickCurrency = true })
            }
            Spacer(Modifier.height(8.dp))
            Text("Category", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            if (cats.isEmpty()) Text("Categories are loading. Check your connection.", style = MaterialTheme.typography.bodySmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.forEach { c ->
                    FilterChip(
                        selected = categoryId == c.id, onClick = { categoryId = c.id; error = null }, label = { Text(c.name) },
                        leadingIcon = { Icon(categoryIcon(c.icon), contentDescription = null, Modifier.size(18.dp)) }, shape = RoundedCornerShape(20.dp),
                    )
                }
                AssistChip(onClick = { newCategory = true }, label = { Text("New") }, leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(18.dp)) }, shape = RoundedCornerShape(20.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Date", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            OutlineButton(if (date == LocalDate.now()) "Today" else date.toString(), { pickDate = true }, icon = { Icon(Icons.Filled.CalendarToday, null) })
            Spacer(Modifier.height(16.dp))
            Text("Payment method", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PAYMENT.forEach { (key, label) -> SelectChip(label, payment == key) { payment = if (payment == key) null else key } }
            }
            Spacer(Modifier.height(16.dp))
            SpendlyTextField(note, { if (it.length <= 200) note = it }, "Note (optional)", singleLine = false, imeAction = ImeAction.Default)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)) }
            Spacer(Modifier.height(16.dp))
        }
        Box(Modifier.padding(16.dp)) {
            PrimaryButton("Save Transaction", loading = vm.saving, onClick = {
                val amt = Money.parseAmount(amountText)
                when {
                    amt == null -> error = "Enter an amount greater than zero"
                    categoryId == null -> error = "Choose a category"
                    date.isAfter(LocalDate.now()) -> error = "Date cannot be in the future"
                    else -> {
                        val iso = if (editing != null && date == Dates.localDate(editing.occurredAt)) editing.occurredAt else Dates.toInstant(date)
                        val req = TransactionRequest(type = type, amount = amt, currency = currency, categoryId = categoryId!!, description = note.trim(), paymentMethod = payment, occurredAt = iso)
                        vm.saveTransaction(editId, req, onSuccess = { queued ->
                            vm.toast(if (queued) "Saved offline. It will sync when you're back online." else if (editId != null) "Transaction updated" else "Transaction saved")
                            onClose()
                        }, onError = { error = it })
                    }
                }
            })
        }
    }
    if (pickDate) SimpleDatePicker(date, { dateStr = it.toString(); pickDate = false }, { pickDate = false })
    if (pickCurrency) CurrencyPickerDialog(vm.currencies.ifEmpty { listOf("USD", "NGN", "GBP", "EUR", "CAD", "AUD").map { com.spendly.app.data.CurrencyDto(it, it) } }, currency, { currency = it; pickCurrency = false }, { pickCurrency = false })
    if (newCategory) {
        var name by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { newCategory = false }, title = { Text("New ${type} category") },
            text = { SpendlyTextField(name, { name = it.take(40); err = null }, "Category name", error = err) },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isBlank()) err = "Enter a name"
                    else vm.createCategory(name, type, onDone = { categoryId = it.id; newCategory = false }, onError = { err = it })
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { newCategory = false }) { Text("Cancel") } },
        )
    }
}
