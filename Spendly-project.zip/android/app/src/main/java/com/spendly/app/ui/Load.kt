package com.spendly.app.ui

sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Ready<T>(val data: T, val offline: Boolean = false) : Load<T>
    data class Failed(val message: String) : Load<Nothing>
}

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String, val isError: Boolean = false)
