package com.spendly.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.spendly.app.core.Dates
import com.spendly.app.core.Money
import com.spendly.app.data.CategoryDto
import com.spendly.app.data.TransactionDto
import com.spendly.app.ui.theme.SpendlyColors

fun parseColor(hex: String, fallback: Color = Color(0xFF6B7280)): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(fallback)

fun categoryIcon(key: String): ImageVector = when (key) {
    "food" -> Icons.Filled.Restaurant
    "transport" -> Icons.Filled.DirectionsCar
    "bills" -> Icons.Filled.Receipt
    "shopping" -> Icons.Filled.ShoppingBag
    "education" -> Icons.Filled.School
    "health" -> Icons.Filled.LocalHospital
    "entertainment" -> Icons.Filled.Movie
    "salary" -> Icons.Filled.Payments
    "freelance" -> Icons.Filled.Work
    "business" -> Icons.Filled.Business
    "gift" -> Icons.Filled.CardGiftcard
    else -> Icons.Filled.Category
}

@Composable
fun CategoryBadge(category: CategoryDto, size: Dp = 40.dp) = CategoryBadge(category.icon, category.color, size)

@Composable
fun CategoryBadge(icon: String, color: String, size: Dp = 40.dp) {
    val c = parseColor(color)
    Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(c.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        Icon(categoryIcon(icon), contentDescription = null, tint = c, modifier = Modifier.size(size * 0.5f))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    if (onClick != null) {
        Surface(onClick = onClick, modifier = modifier, shape = shape, color = MaterialTheme.colorScheme.surface, border = border) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Surface(modifier = modifier, shape = shape, color = MaterialTheme.colorScheme.surface, border = border) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, loading: Boolean = false, containerColor: Color = MaterialTheme.colorScheme.primary) {
    Button(
        onClick = onClick, enabled = enabled && !loading, modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = containerColor),
    ) {
        if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
        else Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: (@Composable () -> Unit)? = null, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        icon?.invoke(); if (icon != null) Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun SpendlyTextField(
    value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier,
    leading: ImageVector? = null, isPassword: Boolean = false, keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next, onDone: (() -> Unit)? = null, error: String? = null,
    singleLine: Boolean = true, enabled: Boolean = true, prefix: String? = null,
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onValueChange, modifier = modifier.fillMaxWidth(), label = { Text(label) },
        leadingIcon = leading?.let { { Icon(it, contentDescription = null) } },
        prefix = prefix?.let { { Text(it) } },
        trailingIcon = if (isPassword) ({
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = if (visible) "Hide password" else "Show password")
            }
        }) else null,
        visualTransformation = if (isPassword && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.Password else keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        isError = error != null, supportingText = error?.let { { Text(it) } },
        singleLine = singleLine, enabled = enabled, shape = RoundedCornerShape(14.dp),
    )
}

@Composable
fun ScreenHeader(title: String, modifier: Modifier = Modifier, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        }
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f).padding(start = if (onBack == null) 4.dp else 0.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            TextButton(onClick = onAction) { Text(action, color = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
fun SpendlyProgress(percent: Int, color: Color, modifier: Modifier = Modifier) {
    val p = (percent.coerceIn(0, 100)) / 100f
    Box(modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.outlineVariant)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(p).clip(CircleShape).background(color))
    }
}

fun statusColor(status: String, base: Color): Color = when (status) {
    "exceeded" -> SpendlyColors.Expense
    "warning" -> SpendlyColors.Warning
    else -> base
}

@Composable
fun TransactionRow(tx: TransactionDto, onClick: () -> Unit, showDate: Boolean = false) {
    val amountColor = if (tx.isIncome) SpendlyColors.Income else SpendlyColors.Expense
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CategoryBadge(tx.category)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tx.category.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
            Text(
                tx.description.ifBlank { tx.paymentMethod?.replace('_', ' ')?.replaceFirstChar { it.uppercase() } ?: " " },
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                Money.format(if (tx.isIncome) tx.amount else -tx.amount, tx.currency, signed = true),
                color = amountColor, style = MaterialTheme.typography.titleSmall, maxLines = 1,
            )
            Text(
                if (tx.isPending) "Waiting to sync" else if (showDate) Dates.shortDate(tx.occurredAt) else Dates.time(tx.occurredAt),
                style = MaterialTheme.typography.bodySmall, color = if (tx.isPending) SpendlyColors.Warning else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun LoadingState(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().semantics { contentDescription = "Loading" }, contentAlignment = Alignment.Center) { CircularProgressIndicator(color = MaterialTheme.colorScheme.primary) }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, message: String, modifier: Modifier = Modifier, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            PrimaryButton(actionLabel, onAction, Modifier.widthIn(max = 280.dp))
        }
    }
}

@Composable
fun ErrorState(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp))
        Text("Something went wrong", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Try again", onRetry, Modifier.widthIn(max = 240.dp))
    }
}

@Composable
fun OfflineBanner(online: Boolean, pending: Int) {
    if (online && pending == 0) return
    val text = when {
        !online && pending > 0 -> "You're offline. $pending transaction${if (pending == 1) "" else "s"} will sync when you're back online."
        !online -> "You're offline. Showing your last saved data."
        else -> "Syncing $pending transaction${if (pending == 1) "" else "s"}…"
    }
    Row(
        Modifier.fillMaxWidth().background(SpendlyColors.Warning.copy(alpha = 0.18f)).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.WifiOff, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun ConfirmDialog(title: String, message: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit, destructive: Boolean = false) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun MonthStepper(month: String, onPrev: () -> Unit, onNext: (() -> Unit)?, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = onPrev) { Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous month") }
        Text(Dates.monthLabel(month), style = MaterialTheme.typography.titleMedium)
        IconButton(onClick = { onNext?.invoke() }, enabled = onNext != null) { Icon(Icons.Filled.ChevronRight, contentDescription = "Next month") }
    }
}

@Composable
fun SelectChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick, label = { Text(label) }, shape = RoundedCornerShape(20.dp),
        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primary, selectedLabelColor = MaterialTheme.colorScheme.onPrimary),
    )
}

@Composable
fun PremiumBadge(modifier: Modifier = Modifier) {
    Row(modifier.clip(CircleShape).background(SpendlyColors.Warning.copy(alpha = 0.2f)).padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Star, contentDescription = null, tint = SpendlyColors.Warning, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Text("Premium", style = MaterialTheme.typography.labelSmall, color = SpendlyColors.Warning)
    }
}

/** Donut chart drawn from backend category totals. */
@Composable
fun DonutChart(slices: List<Pair<Float, Color>>, modifier: Modifier = Modifier, centerTop: String, centerBottom: String) {
    val track = MaterialTheme.colorScheme.outlineVariant
    Box(modifier.size(140.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(14.dp)) {
            val stroke = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Butt)
            drawArc(track, 0f, 360f, false, style = stroke)
            val total = slices.sumOf { it.first.toDouble() }.toFloat()
            var start = -90f
            if (total > 0f) for ((v, color) in slices) {
                val sweep = v / total * 360f
                drawArc(color, start, (sweep - 1.5f).coerceAtLeast(0.5f), false, style = stroke)
                start += sweep
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerTop, style = MaterialTheme.typography.titleSmall, maxLines = 1)
            Text(centerBottom, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Grouped bars: income vs expenses per month. */
@Composable
fun IncomeExpenseBars(points: List<Triple<String, Double, Double>>, modifier: Modifier = Modifier, expensesOnly: Boolean = false) {
    val incomeColor = SpendlyColors.Primary
    val expenseColor = SpendlyColors.Deep.let { if (MaterialTheme.colorScheme.background.luminanceIsLow()) Color(0xFF7ED3AC) else it }
    val max = (points.maxOfOrNull { maxOf(it.second, it.third) } ?: 0.0).coerceAtLeast(1.0)
    Column(modifier) {
        Row(Modifier.fillMaxWidth().height(140.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceEvenly) {
            points.forEach { (_, income, expense) ->
                Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
                    if (!expensesOnly) {
                        Box(Modifier.width(10.dp).fillMaxHeight((income / max).toFloat().coerceIn(0.02f, 1f)).clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)).background(incomeColor))
                        Spacer(Modifier.width(3.dp))
                    }
                    Box(Modifier.width(10.dp).fillMaxHeight((expense / max).toFloat().coerceIn(0.02f, 1f)).clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)).background(expenseColor))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            points.forEach { (label, _, _) -> Text(label, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (!expensesOnly) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                LegendDot("Income", incomeColor); LegendDot("Expenses", expenseColor)
            }
        }
    }
}

private fun Color.luminanceIsLow(): Boolean = (red * 0.299f + green * 0.587f + blue * 0.114f) < 0.4f

@Composable
fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Simple searchable picker used for currencies. */
@Composable
fun CurrencyPickerDialog(currencies: List<com.spendly.app.data.CurrencyDto>, selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, currencies) {
        val q = query.trim()
        if (q.isEmpty()) currencies else currencies.filter { it.code.contains(q, true) || it.name.contains(q, true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Choose currency") },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                if (currencies.isEmpty()) Text("Currency list unavailable offline.", style = MaterialTheme.typography.bodySmall)
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(filtered.size, key = { filtered[it].code }) { i ->
                        val c = filtered[i]
                        Row(Modifier.fillMaxWidth().clickable { onSelect(c.code) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(c.code, Modifier.width(52.dp), style = MaterialTheme.typography.titleSmall)
                            Text(c.name, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (c.code == selected) Icon(Icons.Filled.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
fun CurrencyChip(code: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AssistChip(
        onClick = onClick, modifier = modifier, label = { Text(code, fontWeight = FontWeight.SemiBold) },
        trailingIcon = { Icon(Icons.Filled.ExpandMore, contentDescription = "Change currency", modifier = Modifier.size(18.dp)) },
        shape = RoundedCornerShape(20.dp),
    )
}

@Composable
fun <T> LoadView(state: com.spendly.app.ui.Load<T>, onRetry: () -> Unit, content: @Composable (T) -> Unit) {
    when (state) {
        com.spendly.app.ui.Load.Loading -> LoadingState()
        is com.spendly.app.ui.Load.Failed -> ErrorState(state.message, onRetry)
        is com.spendly.app.ui.Load.Ready -> content(state.data)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleDatePicker(initial: java.time.LocalDate?, onPick: (java.time.LocalDate) -> Unit, onDismiss: () -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial?.atStartOfDay(java.time.ZoneOffset.UTC)?.toInstant()?.toEpochMilli())
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { state.selectedDateMillis?.let { onPick(java.time.Instant.ofEpochMilli(it).atZone(java.time.ZoneOffset.UTC).toLocalDate()) } }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    ) { DatePicker(state = state) }
}
