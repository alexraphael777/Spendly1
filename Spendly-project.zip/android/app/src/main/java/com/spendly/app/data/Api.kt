package com.spendly.app.data

import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.HTTP
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/** The only network surface of the app. Note: there is no Anthropic endpoint here, AI goes through Spendly's backend. */
interface SpendlyApi {
    @POST("api/auth/register") suspend fun register(@Body body: RegisterRequest): AuthResponse
    @POST("api/auth/login") suspend fun login(@Body body: LoginRequest): AuthResponse
    @POST("api/auth/google") suspend fun google(@Body body: GoogleRequest): AuthResponse
    @POST("api/auth/forgot-password") suspend fun forgotPassword(@Body body: ForgotRequest): MessageResponse
    @POST("api/auth/reset-password") suspend fun resetPassword(@Body body: ResetRequest): MessageResponse
    @POST("api/auth/logout") suspend fun logout(@Body body: RefreshRequest)

    @GET("api/me") suspend fun me(): UserDto
    @PATCH("api/me") suspend fun updateMe(@Body body: UpdateMeRequest): UserDto
    @POST("api/me/password") suspend fun changePassword(@Body body: ChangePasswordRequest): TokenResponse
    @HTTP(method = "DELETE", path = "api/me", hasBody = true) suspend fun deleteMe(@Body body: DeleteMeRequest)

    @GET("api/currencies") suspend fun currencies(): CurrenciesResponse
    @GET("api/categories") suspend fun categories(): CategoriesResponse
    @POST("api/categories") suspend fun createCategory(@Body body: CategoryRequest): CategoryDto

    @GET("api/transactions") suspend fun transactions(
        @Query("q") q: String? = null, @Query("type") type: String? = null, @Query("categoryId") categoryId: String? = null,
        @Query("month") month: String? = null, @Query("from") from: String? = null, @Query("to") to: String? = null,
        @Query("currency") currency: String? = null, @Query("limit") limit: Int = 50, @Query("offset") offset: Int = 0,
    ): TransactionPage
    @POST("api/transactions") suspend fun createTransaction(@Body body: TransactionRequest): TransactionDto
    @PUT("api/transactions/{id}") suspend fun updateTransaction(@Path("id") id: String, @Body body: TransactionRequest): TransactionDto
    @DELETE("api/transactions/{id}") suspend fun deleteTransaction(@Path("id") id: String)

    @GET("api/budgets") suspend fun budgets(@Query("month") month: String): BudgetsResponse
    @POST("api/budgets") suspend fun createBudget(@Body body: BudgetRequest): BudgetDto
    @PUT("api/budgets/{id}") suspend fun updateBudget(@Path("id") id: String, @Body body: BudgetUpdate): BudgetDto
    @DELETE("api/budgets/{id}") suspend fun deleteBudget(@Path("id") id: String)

    @GET("api/reports/summary") suspend fun summary(@Query("month") month: String): SummaryDto
    @GET("api/reports") suspend fun report(@Query("month") month: String): ReportDto

    @GET("api/notifications") suspend fun notifications(): NotificationsResponse
    @POST("api/notifications/read-all") suspend fun markAllRead()
    @PATCH("api/notifications/{id}/read") suspend fun markRead(@Path("id") id: String)
    @DELETE("api/notifications/{id}") suspend fun dismissNotification(@Path("id") id: String)

    @GET("api/subscription") suspend fun subscription(): SubscriptionDto
    @POST("api/subscription/checkout") suspend fun checkout(@Body body: Map<String, String> = emptyMap())

    @POST("api/ai/chat") suspend fun chat(@Body body: AiRequest): AiResponse
}
