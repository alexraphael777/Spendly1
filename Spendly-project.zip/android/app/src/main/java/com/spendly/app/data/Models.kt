package com.spendly.app.data

import kotlinx.serialization.Serializable

@Serializable data class ErrorBody(val code: String = "", val message: String = "")
@Serializable data class ErrorEnvelope(val error: ErrorBody = ErrorBody())

// ---- auth / user ----
@Serializable data class RegisterRequest(val name: String, val email: String, val password: String)
@Serializable data class LoginRequest(val email: String, val password: String)
@Serializable data class GoogleRequest(val idToken: String)
@Serializable data class RefreshRequest(val refreshToken: String)
@Serializable data class ForgotRequest(val email: String)
@Serializable data class ResetRequest(val email: String, val code: String, val newPassword: String)
@Serializable data class MessageResponse(val message: String = "")
@Serializable data class TokenResponse(val accessToken: String, val refreshToken: String, val expiresIn: Int = 0)
@Serializable data class AuthResponse(val accessToken: String, val refreshToken: String, val expiresIn: Int = 0, val user: UserDto)

@Serializable data class NotifPrefs(val budgetAlerts: Boolean = true, val insights: Boolean = true, val transactions: Boolean = true)
@Serializable data class LimitsDto(
    val customCategories: Int? = null, val budgets: Int? = null, val aiMessagesPerDay: Int = 10,
    val trendMonths: Int = 6, val advancedFilters: Boolean = false, val advancedReports: Boolean = false,
)
@Serializable data class SubscriptionDto(
    val plan: String = "free", val status: String = "active", val currentPeriodEnd: String? = null,
    val limits: LimitsDto = LimitsDto(), val paymentsConfigured: Boolean = false,
) { val isPremium: Boolean get() = plan == "premium" }
@Serializable data class UserDto(
    val id: String, val name: String, val email: String, val avatarUrl: String? = null, val preferredCurrency: String = "USD",
    val notificationPrefs: NotifPrefs = NotifPrefs(), val hasPassword: Boolean = true, val createdAt: String = "",
    val subscription: SubscriptionDto = SubscriptionDto(),
)
@Serializable data class UpdateMeRequest(val name: String? = null, val preferredCurrency: String? = null, val notificationPrefs: NotifPrefs? = null)
@Serializable data class ChangePasswordRequest(val currentPassword: String? = null, val newPassword: String)
@Serializable data class DeleteMeRequest(val confirm: String = "DELETE", val password: String? = null)

// ---- reference data ----
@Serializable data class CurrencyDto(val code: String, val name: String, val symbol: String = "", val decimals: Int = 2)
@Serializable data class CurrenciesResponse(val items: List<CurrencyDto>)
@Serializable data class CategoryDto(
    val id: String, val name: String, val icon: String = "other", val color: String = "#6B7280",
    val type: String = "expense", val custom: Boolean = false,
)
@Serializable data class CategoriesResponse(val items: List<CategoryDto>)
@Serializable data class CategoryRequest(val name: String, val type: String, val icon: String = "other", val color: String = "#6B7280")

// ---- transactions ----
@Serializable data class TransactionDto(
    val id: String, val clientId: String? = null, val type: String, val amount: Double, val currency: String,
    val category: CategoryDto, val description: String = "", val paymentMethod: String? = null,
    val occurredAt: String, val createdAt: String = "", val updatedAt: String = "", val convertedAmount: Double? = null,
) {
    val isIncome: Boolean get() = type == "income"
    val isPending: Boolean get() = id.startsWith("pending-")
}
@Serializable data class TransactionPage(val items: List<TransactionDto>, val total: Int = 0, val limit: Int = 50, val offset: Int = 0)
@Serializable data class TransactionRequest(
    val clientId: String? = null, val type: String, val amount: Double, val currency: String, val categoryId: String,
    val description: String = "", val paymentMethod: String? = null, val occurredAt: String,
)

// ---- budgets ----
@Serializable data class BudgetDto(
    val id: String, val category: CategoryDto, val amount: Double, val currency: String, val period: String = "monthly",
    val spent: Double = 0.0, val remaining: Double = 0.0, val percent: Int = 0, val status: String = "ok",
)
@Serializable data class BudgetTotals(val limit: Double = 0.0, val spent: Double = 0.0, val remaining: Double = 0.0, val percent: Int = 0)
@Serializable data class BudgetsResponse(val month: String, val currency: String, val items: List<BudgetDto>, val totals: BudgetTotals = BudgetTotals())
@Serializable data class BudgetRequest(val categoryId: String, val amount: Double, val currency: String)
@Serializable data class BudgetUpdate(val amount: Double, val currency: String)

// ---- reports ----
@Serializable data class CategoryTotal(val id: String, val name: String, val icon: String = "other", val color: String = "#6B7280", val amount: Double, val percent: Double)
@Serializable data class Progress(val basis: String, val limit: Double, val spent: Double, val percent: Int)
@Serializable data class Insight(val kind: String = "info", val text: String)
@Serializable data class SummaryDto(
    val month: String, val currency: String, val hasData: Boolean, val balance: Double, val income: Double, val expenses: Double,
    val previousExpenses: Double = 0.0, val progress: Progress? = null, val categories: List<CategoryTotal> = emptyList(),
    val recent: List<TransactionDto> = emptyList(), val insights: List<Insight> = emptyList(), val unconvertedCount: Int = 0,
)
@Serializable data class ReportSummary(
    val income: Double, val expenses: Double, val net: Double, val transactionCount: Int = 0,
    val savingsRate: Int? = null, val averageDailySpend: Double = 0.0,
)
@Serializable data class TrendPoint(val month: String, val income: Double, val expenses: Double)
@Serializable data class DailyPoint(val date: String, val amount: Double)
@Serializable data class PremiumBlock(
    val unlocked: Boolean = false, val trendMonths: Int = 6, val daily: List<DailyPoint>? = null, val topExpenses: List<TransactionDto>? = null,
)
@Serializable data class ReportDto(
    val month: String, val currency: String, val hasData: Boolean, val summary: ReportSummary,
    val spendingByCategory: List<CategoryTotal> = emptyList(), val trend: List<TrendPoint> = emptyList(),
    val budgetPerformance: List<BudgetDto> = emptyList(), val unconvertedCount: Int = 0, val premium: PremiumBlock = PremiumBlock(),
)

// ---- notifications / AI ----
@Serializable data class NotificationDto(val id: String, val type: String, val title: String, val message: String, val read: Boolean = false, val createdAt: String = "")
@Serializable data class NotificationsResponse(val items: List<NotificationDto>, val unreadCount: Int = 0)
@Serializable data class ChatTurn(val role: String, val content: String)
@Serializable data class AiRequest(val message: String, val history: List<ChatTurn> = emptyList())
@Serializable data class AiResponse(val reply: String, val remainingToday: Int? = null)
