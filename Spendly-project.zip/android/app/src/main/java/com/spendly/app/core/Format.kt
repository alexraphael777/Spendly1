package com.spendly.app.core

import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Currency
import java.util.Locale
import kotlin.math.abs

object Money {
    private val symbols = mutableMapOf(
        "USD" to "$", "NGN" to "₦", "GBP" to "£", "EUR" to "€", "CAD" to "$", "AUD" to "$",
        "JPY" to "¥", "INR" to "₹", "GHS" to "GH₵", "ZAR" to "R",
    )

    fun registerSymbols(map: Map<String, String>) { symbols.putAll(map) }
    fun symbol(code: String): String = symbols[code] ?: code

    fun format(amount: Double, code: String, signed: Boolean = false): String {
        val digits = runCatching { Currency.getInstance(code).defaultFractionDigits }.getOrDefault(2).coerceAtLeast(0)
        val value = abs(amount)
        val whole = value % 1.0 == 0.0
        val nf = NumberFormat.getNumberInstance(Locale.getDefault()).apply {
            minimumFractionDigits = if (whole) 0 else digits
            maximumFractionDigits = digits
        }
        val sym = symbol(code)
        val prefix = if (sym.length > 1 && sym.all { it.isLetter() }) "$sym " else sym
        val body = prefix + nf.format(value)
        return when {
            amount < 0 -> "-$body"
            signed && amount > 0 -> "+$body"
            else -> body
        }
    }

    /** Parses user input like "1,250.50". Returns null unless it is a positive number. */
    fun parseAmount(input: String): Double? = input.replace(",", "").trim().toDoubleOrNull()?.takeIf { it > 0 && it.isFinite() }

    fun defaultCurrency(): String = runCatching { Currency.getInstance(Locale.getDefault()).currencyCode }.getOrDefault("USD")
}

object Dates {
    private val zone: ZoneId get() = ZoneId.systemDefault()
    private val dayFmt = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)
    private val shortFmt = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
    private val timeFmt = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)

    fun localDate(iso: String): LocalDate = Instant.parse(iso).atZone(zone).toLocalDate()
    fun dayHeader(iso: String): String = localDate(iso).format(dayFmt)
    fun shortDate(iso: String): String = localDate(iso).format(shortFmt)
    fun time(iso: String): String = Instant.parse(iso).atZone(zone).format(timeFmt)
    fun currentMonth(): String = YearMonth.now().toString()
    fun shiftMonth(month: String, delta: Long): String = YearMonth.parse(month).plusMonths(delta).toString()
    fun monthLabel(month: String): String {
        val ym = YearMonth.parse(month)
        return ym.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()) + " " + ym.year
    }
    fun monthShort(month: String): String = YearMonth.parse(month).month.getDisplayName(java.time.format.TextStyle.SHORT, Locale.getDefault())

    /** Combines a picked calendar day with the current time of day and returns an ISO instant. */
    fun toInstant(day: LocalDate): String {
        val now = java.time.LocalTime.now()
        return day.atTime(now).atZone(zone).toInstant().toString()
    }
    fun greeting(): String {
        val h = java.time.LocalTime.now().hour
        return when { h < 12 -> "Good morning,"; h < 17 -> "Good afternoon,"; else -> "Good evening," }
    }
}
