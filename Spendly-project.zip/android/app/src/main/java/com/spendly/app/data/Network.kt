package com.spendly.app.data

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.Authenticator
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.Route
import retrofit2.Retrofit
import java.io.IOException
import java.util.TimeZone
import java.util.concurrent.TimeUnit

object Network {
    fun create(baseUrl: String, session: SessionStore, json: Json): SpendlyApi {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS) // the AI endpoint can take a while
            .writeTimeout(20, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val original = chain.request()
                val b = original.newBuilder()
                    .header("Accept", "application/json")
                    .header("X-Tz-Offset", (TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000).toString())
                if (original.header("Authorization") == null) session.accessToken?.let { b.header("Authorization", "Bearer $it") }
                chain.proceed(b.build())
            }
            .authenticator(TokenAuthenticator(session, baseUrl, json))
            .build()
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(SpendlyApi::class.java)
    }
}

/** On a 401, refreshes the access token once (rotating refresh token) and retries. Signs the user out if refresh is rejected. */
class TokenAuthenticator(private val session: SessionStore, private val baseUrl: String, private val json: Json) : Authenticator {
    private val plain = OkHttpClient()

    @Synchronized
    override fun authenticate(route: Route?, response: Response): Request? {
        if (response.request.header("X-Retry-Auth") != null) return null
        if (response.request.url.encodedPath.contains("/api/auth/")) return null
        val sent = response.request.header("Authorization")?.removePrefix("Bearer ")
        val current = session.accessToken
        if (current != null && sent != current) return retry(response, current) // another call already refreshed
        val refresh = session.refreshToken ?: return null
        val req = Request.Builder().url(baseUrl + "api/auth/refresh")
            .post(json.encodeToString(RefreshRequest(refresh)).toRequestBody("application/json".toMediaType())).build()
        return try {
            plain.newCall(req).execute().use { r ->
                when {
                    r.code == 401 -> { session.clear(); null }
                    !r.isSuccessful -> null
                    else -> {
                        val t = json.decodeFromString<TokenResponse>(r.body?.string().orEmpty())
                        session.save(t.accessToken, t.refreshToken)
                        retry(response, t.accessToken)
                    }
                }
            }
        } catch (e: IOException) {
            null
        }
    }

    private fun retry(response: Response, token: String): Request =
        response.request.newBuilder().header("Authorization", "Bearer $token").header("X-Retry-Auth", "1").build()
}
