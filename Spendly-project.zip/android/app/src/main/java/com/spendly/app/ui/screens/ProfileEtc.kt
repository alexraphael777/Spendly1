package com.spendly.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.spendly.app.BuildConfig
import com.spendly.app.core.Dates
import com.spendly.app.data.NotifPrefs
import com.spendly.app.data.NotificationDto
import com.spendly.app.data.UpdateMeRequest
import com.spendly.app.ui.AppViewModel
import com.spendly.app.ui.AuthValidation
import com.spendly.app.ui.components.*
import com.spendly.app.ui.theme.SpendlyColors

@Composable
fun ProfileScreen(vm: AppViewModel, onBack: () -> Unit, onPremium: () -> Unit, onSignedOut: () -> Unit) {
    val user = vm.user
    var editName by remember { mutableStateOf(false) }
    var pickCurrency by remember { mutableStateOf(false) }
    var changePw by remember { mutableStateOf(false) }
    var deleteAcc by remember { mutableStateOf(false) }
    var signOut by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Profile & Settings", onBack = onBack)
        if (user == null) { LoadingState(); return@Column }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    Text(user.name.firstOrNull()?.uppercase() ?: "S", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(user.name, style = MaterialTheme.typography.titleMedium)
                    Text(user.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (user.subscription.isPremium) PremiumBadge()
            }
            SettingsGroup("Account") {
                SettingsRow(Icons.Filled.Person, "Edit profile", user.name) { editName = true }
                SettingsRow(Icons.Filled.Payments, "Preferred currency", user.preferredCurrency) { pickCurrency = true }
            }
            SettingsGroup("Subscription") {
                SettingsRow(Icons.Filled.Star, if (user.subscription.isPremium) "Spendly Premium" else "Free plan", if (user.subscription.isPremium) "Active" else "See what Premium includes", onPremium)
            }
            SettingsGroup("Notifications") {
                val p = user.notificationPrefs
                fun set(n: NotifPrefs) = vm.updateProfile(UpdateMeRequest(notificationPrefs = n))
                SwitchRow("Budget alerts", p.budgetAlerts) { set(p.copy(budgetAlerts = it)) }
                SwitchRow("AI & insights", p.insights) { set(p.copy(insights = it)) }
                SwitchRow("Transaction updates", p.transactions) { set(p.copy(transactions = it)) }
            }
            SettingsGroup("Security") {
                SettingsRow(Icons.Filled.Lock, if (user.hasPassword) "Change password" else "Set a password", "") { changePw = true }
            }
            SettingsGroup("Privacy") {
                Text("Your data is stored in your private Spendly account and is only visible to you. The AI assistant receives a summary of your finances for each question and does not see other users' data.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(12.dp))
                SettingsRow(Icons.Filled.DeleteForever, "Delete account", "Permanently remove your account and data", destructive = true) { deleteAcc = true }
            }
            Spacer(Modifier.height(16.dp))
            OutlineButton("Sign out", { signOut = true }, icon = { Icon(Icons.Filled.Logout, null) })
            Text("Spendly ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 16.dp))
        }
    }
    if (editName && user != null) {
        var name by remember { mutableStateOf(user.name) }
        AlertDialog(onDismissRequest = { editName = false }, title = { Text("Edit profile") },
            text = { SpendlyTextField(name, { name = it.take(80) }, "Full name") },
            confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { vm.updateProfile(UpdateMeRequest(name = name.trim())) { editName = false } }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancel") } })
    }
    if (pickCurrency && user != null) CurrencyPickerDialog(vm.currencies, user.preferredCurrency, { vm.updateProfile(UpdateMeRequest(preferredCurrency = it)); pickCurrency = false }, { pickCurrency = false })
    if (changePw && user != null) {
        var cur by remember { mutableStateOf("") }; var new by remember { mutableStateOf("") }; var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest = { changePw = false }, title = { Text(if (user.hasPassword) "Change password" else "Set a password") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (user.hasPassword) SpendlyTextField(cur, { cur = it }, "Current password", isPassword = true)
                    SpendlyTextField(new, { new = it }, "New password", isPassword = true, error = err)
                }
            },
            confirmButton = {
                TextButton(enabled = !vm.busy, onClick = {
                    val v = AuthValidation.password(new)
                    if (v != null) err = v else vm.changePassword(cur.ifBlank { null }, new, { changePw = false; vm.toast("Password updated") }, { err = it })
                }) { Text("Update") }
            },
            dismissButton = { TextButton(onClick = { changePw = false }) { Text("Cancel") } })
    }
    if (deleteAcc && user != null) {
        var pw by remember { mutableStateOf("") }; var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest = { deleteAcc = false }, title = { Text("Delete account?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This permanently deletes your account, transactions, budgets and notifications. This cannot be undone.")
                    if (user.hasPassword) SpendlyTextField(pw, { pw = it }, "Confirm with your password", isPassword = true, error = err)
                    else err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(enabled = !vm.busy, onClick = { vm.deleteAccount(pw.ifBlank { null }, onSignedOut) { err = it } }) { Text("Delete forever", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteAcc = false }) { Text("Cancel") } })
    }
    if (signOut) ConfirmDialog("Sign out?", "You'll need to sign in again to see your data.", "Sign out", onConfirm = { signOut = false; vm.signOut(onSignedOut) }, onDismiss = { signOut = false })
}

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
    SCard(Modifier.fillMaxWidth(), content = content)
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String, destructive: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked, onChange)
    }
}

@Composable
fun NotificationsScreen(vm: AppViewModel, onBack: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf("all") }
    val tabs = listOf("all" to "All", "alert" to "Alerts", "transaction" to "Transactions", "insight" to "AI & Insights", "system" to "System")
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Notifications", onBack = onBack, actions = {
            TextButton(onClick = vm::markAllRead, enabled = vm.unreadCount > 0) { Text("Mark all read") }
        })
        Row(Modifier.horizontalScrollCompat().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.forEach { (k, label) -> SelectChip(label, tab == k) { tab = k } }
        }
        LoadView(vm.notifications, vm::loadNotifications) { data ->
            val items = if (tab == "all") data.items else data.items.filter { it.type == tab }
            if (items.isEmpty()) EmptyState(Icons.Filled.NotificationsNone, "You're all caught up", "New alerts and insights will show up here.")
            else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { n -> NotificationRow(n, onClick = { vm.markRead(n) }, onDismiss = { vm.dismiss(n) }) }
            }
        }
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.horizontalScroll(rememberScrollState())

@Composable
private fun NotificationRow(n: NotificationDto, onClick: () -> Unit, onDismiss: () -> Unit) {
    val icon = when (n.type) { "alert" -> Icons.Filled.Warning; "transaction" -> Icons.Filled.Receipt; "insight" -> Icons.Filled.AutoAwesome; else -> Icons.Filled.Info }
    val tint = if (n.type == "alert") SpendlyColors.Warning else MaterialTheme.colorScheme.primary
    SCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = tint, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(n.title, style = MaterialTheme.typography.titleSmall, fontWeight = if (n.read) FontWeight.Medium else FontWeight.Bold, modifier = Modifier.weight(1f, fill = false))
                    if (!n.read) Box(Modifier.padding(start = 6.dp).size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                }
                Text(n.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (n.createdAt.isNotBlank()) Text(Dates.shortDate(n.createdAt) + " " + Dates.time(n.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Close, contentDescription = "Dismiss notification", modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
fun PremiumScreen(vm: AppViewModel, onBack: () -> Unit) {
    val sub = vm.user?.subscription
    val rows = listOf(
        Triple("Core expense & income tracking", true, true),
        Triple("Standard categories", true, true),
        Triple("Budgets", "Up to 5", "Unlimited"),
        Triple("Custom categories", "Up to 3", "Unlimited"),
        Triple("Reports history", "6 months", "12 months"),
        Triple("Advanced reports & filters", false, true),
        Triple("AI assistant", "10 messages / day", "100 / day, deeper analysis"),
    )
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Spendly Premium", onBack = onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            SCard(Modifier.fillMaxWidth()) {
                Text(if (sub?.isPremium == true) "You're on Premium" else "You're on the Free plan", style = MaterialTheme.typography.titleMedium)
                sub?.currentPeriodEnd?.let { Text("Renews or ends ${Dates.shortDate(it)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            Spacer(Modifier.height(12.dp))
            SCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(bottom = 6.dp)) { Spacer(Modifier.weight(1.4f)); Text("Free", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge); Text("Premium", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = SpendlyColors.Warning) }
                rows.forEach { (label, free, prem) ->
                    HorizontalDivider()
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, Modifier.weight(1.4f), style = MaterialTheme.typography.bodyMedium)
                        Box(Modifier.weight(1f)) { Cell(free) }
                        Box(Modifier.weight(1f)) { Cell(prem) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            if (sub?.isPremium != true) {
                PrimaryButton("Upgrade to Premium", { vm.startCheckout() })
                Text("Purchases aren't available in this version yet. Nothing is charged.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun Cell(v: Any) {
    when (v) {
        true -> Icon(Icons.Filled.Check, "Included", tint = MaterialTheme.colorScheme.primary)
        false -> Icon(Icons.Filled.Remove, "Not included", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        else -> Text(v.toString(), style = MaterialTheme.typography.bodySmall)
    }
}
