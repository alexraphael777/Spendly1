package com.spendly.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.spendly.app.AppContainer
import com.spendly.app.core.Dates
import com.spendly.app.core.Money
import com.spendly.app.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Holds all signed-in app state. The backend is the source of truth; this only presents it. */
class AppViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.repo
    val online: StateFlow<Boolean> = c.connectivity.online

    var user by mutableStateOf<UserDto?>(null); private set
    var summary by mutableStateOf<Load<SummaryDto>>(Load.Loading); private set
    var txs by mutableStateOf<Load<List<TransactionDto>>>(Load.Loading); private set
    var txTotal by mutableIntStateOf(0); private set
    var filter by mutableStateOf(TxFilter(month = Dates.currentMonth())); private set
    var budgets by mutableStateOf<Load<BudgetsResponse>>(Load.Loading); private set
    var report by mutableStateOf<Load<ReportDto>>(Load.Loading); private set
    var reportMonth by mutableStateOf(Dates.currentMonth()); private set
    var notifications by mutableStateOf<Load<NotificationsResponse>>(Load.Loading); private set
    var categories by mutableStateOf<List<CategoryDto>>(emptyList()); private set
    var currencies by mutableStateOf<List<CurrencyDto>>(emptyList()); private set
    var pending by mutableStateOf<List<TransactionRequest>>(emptyList()); private set
    var saving by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set

    val chat = mutableStateListOf<ChatMessage>()
    var chatBusy by mutableStateOf(false); private set
    var aiRemaining by mutableStateOf<Int?>(null); private set

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events
    private var nextId = 1L
    private var started = false
    private var watchingNetwork = false
    private var txJob: Job? = null

    val preferredCurrency: String get() = user?.preferredCurrency ?: Money.defaultCurrency()
    val isPremium: Boolean get() = user?.subscription?.isPremium == true
    val unreadCount: Int get() = (notifications as? Load.Ready)?.data?.unreadCount ?: 0

    fun toast(msg: String) { _events.tryEmit(msg) }

    // ---------- lifecycle ----------
    fun start() {
        if (started) return
        started = true
        viewModelScope.launch {
            repo.cachedUser()?.let { user = it }
            repo.me().onSuccess { user = it.data }
            repo.currencies().onSuccess { r ->
                currencies = r.data
                Money.registerSymbols(r.data.filter { it.symbol.isNotBlank() }.associate { it.code to it.symbol })
            }
            repo.categories().onSuccess { categories = it.data }
            refreshAll()
            flushPending()
        }
        if (!watchingNetwork) {
            watchingNetwork = true
            viewModelScope.launch { online.collect { isOn -> if (isOn && started) { flushPending(); refreshAll() } } }
        }
    }

    fun reset() {
        started = false
        user = null; summary = Load.Loading; txs = Load.Loading; txTotal = 0; budgets = Load.Loading; report = Load.Loading
        notifications = Load.Loading; categories = emptyList(); pending = emptyList(); chat.clear(); aiRemaining = null
        filter = TxFilter(month = Dates.currentMonth()); reportMonth = Dates.currentMonth(); chatBusy = false
    }

    private fun <T> merge(current: Load<T>, result: Result<Loaded<T>>): Load<T> = result.fold(
        onSuccess = { Load.Ready(it.data, it is Loaded.Stale) },
        onFailure = { e -> if (current is Load.Ready) current.copy(offline = true) else Load.Failed(e.message ?: "Something went wrong") },
    )

    fun refreshAll() {
        loadSummary(); loadTransactions(); loadBudgets(); loadReport(); loadNotifications(); refreshPending()
    }

    private fun refreshPending() { pending = repo.pendingRequests() }

    private fun flushPending() {
        viewModelScope.launch {
            if (repo.pendingRequests().isEmpty()) return@launch
            val n = repo.flushPending()
            refreshPending()
            if (n > 0) { toast("Synced $n offline transaction${if (n == 1) "" else "s"}"); refreshAll() }
        }
    }

    fun retryAll() { summary = if (summary is Load.Failed) Load.Loading else summary; refreshAll() }

    // ---------- reads ----------
    fun loadSummary() { viewModelScope.launch { summary = merge(summary, repo.summary(Dates.currentMonth())) } }
    fun loadBudgets() { viewModelScope.launch { budgets = merge(budgets, repo.budgets(Dates.currentMonth())) } }
    fun loadNotifications() { viewModelScope.launch { notifications = merge(notifications, repo.notifications()) } }
    fun loadReport(month: String = reportMonth) {
        reportMonth = month
        viewModelScope.launch { report = merge(report, repo.report(month)) }
    }
    fun shiftReportMonth(delta: Long) {
        val next = Dates.shiftMonth(reportMonth, delta)
        if (next > Dates.currentMonth()) return
        report = Load.Loading
        loadReport(next)
    }

    fun setFilter(f: TxFilter) {
        filter = f
        txs = Load.Loading
        loadTransactions()
    }

    fun loadTransactions() {
        txJob?.cancel()
        txJob = viewModelScope.launch {
            val r = repo.transactions(filter)
            r.onSuccess { txTotal = it.data.total }
            r.onFailure { e -> if ((e as? AppError)?.isPremiumRequired == true) toast(e.message ?: "Premium required") }
            txs = merge(txs, r.map { l -> if (l is Loaded.Stale) Loaded.Stale(l.data.items) else Loaded.Fresh(l.data.items) })
        }
    }

    fun loadMoreTransactions() {
        val cur = (txs as? Load.Ready)?.data ?: return
        if (cur.size >= txTotal) return
        viewModelScope.launch {
            repo.transactions(filter, offset = cur.size).onSuccess { txs = Load.Ready(cur + it.data.items, false); txTotal = it.data.total }
        }
    }

    /** Server transactions plus entries still waiting to sync, filtered the same way the server filters. */
    fun visibleTransactions(): List<TransactionDto> {
        val server = (txs as? Load.Ready)?.data ?: emptyList()
        val f = filter
        val queued = pending.filter { p ->
            (f.type == null || p.type == f.type) && (f.categoryId == null || p.categoryId == f.categoryId) &&
                (f.month == null || Dates.localDate(p.occurredAt).toString().startsWith(f.month)) &&
                (f.query.isBlank() || p.description.contains(f.query, ignoreCase = true)) && !f.hasAdvanced
        }.map { p ->
            TransactionDto(
                id = "pending-${p.clientId}", clientId = p.clientId, type = p.type, amount = p.amount, currency = p.currency,
                category = categories.firstOrNull { it.id == p.categoryId } ?: CategoryDto(p.categoryId, "Category"),
                description = p.description, paymentMethod = p.paymentMethod, occurredAt = p.occurredAt,
            )
        }
        return (queued + server).sortedByDescending { it.occurredAt }
    }

    fun findTransaction(id: String): TransactionDto? =
        visibleTransactions().firstOrNull { it.id == id } ?: (summary as? Load.Ready)?.data?.recent?.firstOrNull { it.id == id }

    // ---------- transactions ----------
    fun saveTransaction(editId: String?, req: TransactionRequest, onSuccess: (queued: Boolean) -> Unit, onError: (String) -> Unit) {
        if (saving) return
        saving = true
        viewModelScope.launch {
            val result = if (editId == null) repo.createTransaction(req).map { it == null } else repo.updateTransaction(editId, req).map { false }
            saving = false
            result.fold(
                onSuccess = { queued -> refreshPending(); refreshAfterChange(); onSuccess(queued) },
                onFailure = { onError(it.message ?: "Could not save") },
            )
        }
    }

    fun deleteTransaction(id: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deleteTransaction(id).fold(
                onSuccess = { refreshAfterChange(); onDone() },
                onFailure = { toast(it.message ?: "Could not delete") },
            )
        }
    }

    private fun refreshAfterChange() { loadSummary(); loadTransactions(); loadBudgets(); loadReport(); loadNotifications() }

    // ---------- budgets & categories ----------
    fun saveBudget(existing: BudgetDto?, categoryId: String?, amount: Double, currency: String, onDone: () -> Unit, onError: (String) -> Unit) {
        busy = true
        viewModelScope.launch {
            val r = if (existing == null) repo.createBudget(BudgetRequest(categoryId.orEmpty(), amount, currency)).map { }
            else repo.updateBudget(existing.id, BudgetUpdate(amount, currency)).map { }
            busy = false
            r.fold(onSuccess = { loadBudgets(); loadSummary(); loadReport(); onDone() }, onFailure = { onError(it.message ?: "Could not save budget") })
        }
    }

    fun deleteBudget(id: String) {
        viewModelScope.launch {
            repo.deleteBudget(id).fold(onSuccess = { loadBudgets(); loadSummary(); loadReport() }, onFailure = { toast(it.message ?: "Could not delete") })
        }
    }

    fun createCategory(name: String, type: String, onDone: (CategoryDto) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            repo.createCategory(name.trim(), type).fold(
                onSuccess = { cat -> categories = categories + cat; onDone(cat) },
                onFailure = { onError(it.message ?: "Could not create category") },
            )
        }
    }

    // ---------- notifications ----------
    fun markAllRead() {
        val cur = (notifications as? Load.Ready)?.data ?: return
        notifications = Load.Ready(cur.copy(items = cur.items.map { it.copy(read = true) }, unreadCount = 0))
        viewModelScope.launch { repo.markAllRead().onFailure { loadNotifications() } }
    }
    fun markRead(n: NotificationDto) {
        if (n.read) return
        val cur = (notifications as? Load.Ready)?.data ?: return
        notifications = Load.Ready(cur.copy(items = cur.items.map { if (it.id == n.id) it.copy(read = true) else it }, unreadCount = (cur.unreadCount - 1).coerceAtLeast(0)))
        viewModelScope.launch { repo.markRead(n.id) }
    }
    fun dismiss(n: NotificationDto) {
        val cur = (notifications as? Load.Ready)?.data ?: return
        notifications = Load.Ready(cur.copy(items = cur.items.filter { it.id != n.id }, unreadCount = if (n.read) cur.unreadCount else (cur.unreadCount - 1).coerceAtLeast(0)))
        viewModelScope.launch { repo.dismissNotification(n.id).onFailure { loadNotifications() } }
    }

    // ---------- profile ----------
    fun updateProfile(req: UpdateMeRequest, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repo.updateMe(req).fold(
                onSuccess = { user = it; if (req.preferredCurrency != null) refreshAll(); onDone() },
                onFailure = { toast(it.message ?: "Could not update profile") },
            )
        }
    }
    fun changePassword(current: String?, new: String, onDone: () -> Unit, onError: (String) -> Unit) {
        busy = true
        viewModelScope.launch {
            repo.changePassword(current, new).fold(
                onSuccess = { busy = false; user = user?.copy(hasPassword = true); onDone() },
                onFailure = { busy = false; onError(it.message ?: "Could not change password") },
            )
        }
    }
    fun deleteAccount(password: String?, onDone: () -> Unit, onError: (String) -> Unit) {
        busy = true
        viewModelScope.launch {
            repo.deleteAccount(password).fold(onSuccess = { busy = false; reset(); onDone() }, onFailure = { busy = false; onError(it.message ?: "Could not delete account") })
        }
    }
    fun signOut(onDone: () -> Unit) {
        viewModelScope.launch { repo.signOut(); reset(); onDone() }
    }
    fun startCheckout() {
        viewModelScope.launch { repo.checkout().onFailure { toast(it.message ?: "Premium is not available yet") } }
    }

    // ---------- AI assistant ----------
    fun sendChat(text: String, addUser: Boolean = true) {
        val msg = text.trim()
        if (msg.isEmpty() || chatBusy) return
        val history = chat.filter { !it.isError }.takeLast(8).map { ChatTurn(if (it.fromUser) "user" else "assistant", it.text) }
        if (addUser) chat.add(ChatMessage(nextId++, true, msg))
        chatBusy = true
        viewModelScope.launch {
            repo.chat(msg, history).fold(
                onSuccess = { chat.add(ChatMessage(nextId++, false, it.reply)); aiRemaining = it.remainingToday },
                onFailure = { chat.add(ChatMessage(nextId++, false, it.message ?: "The assistant is unavailable right now.", isError = true)) },
            )
            chatBusy = false
        }
    }
    fun retryChat() {
        val last = chat.lastOrNull { it.fromUser } ?: return
        chat.removeAll { it.isError }
        sendChat(last.text, addUser = false)
    }
}
