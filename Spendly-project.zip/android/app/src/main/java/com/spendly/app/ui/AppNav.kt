package com.spendly.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.spendly.app.AppContainer
import com.spendly.app.ui.components.OfflineBanner
import com.spendly.app.ui.screens.*
import com.spendly.app.ui.theme.SpendlyColors
import kotlinx.coroutines.delay

fun <T : ViewModel> vmFactory(make: () -> T) = object : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <V : ViewModel> create(modelClass: Class<V>): V = make() as V
}

@Composable
fun SpendlyRoot(container: AppContainer) {
    val auth: AuthViewModel = viewModel(factory = vmFactory { AuthViewModel(container) })
    val app: AppViewModel = viewModel(factory = vmFactory { AppViewModel(container) })
    val boot by auth.boot.collectAsStateWithLifecycle()
    var minSplash by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(900); minSplash = true }

    // Token refresh failure elsewhere in the app clears the session; follow it back to sign in.
    val signedIn by container.session.signedIn.collectAsStateWithLifecycle()
    LaunchedEffect(signedIn, boot) { if (!signedIn && boot is Boot.SignedIn) { app.reset(); auth.markSignedOut() } }

    when {
        boot is Boot.Loading || !minSplash -> SplashScreen()
        boot is Boot.SignedOut -> AuthNav(auth, app, startOnboarding = !(boot as Boot.SignedOut).onboarded)
        else -> {
            LaunchedEffect(Unit) { app.start() }
            MainNav(app, onSignedOut = { auth.markSignedOut() })
        }
    }
}

@Composable
private fun AuthNav(auth: AuthViewModel, app: AppViewModel, startOnboarding: Boolean) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = if (startOnboarding) "onboarding" else "signin") {
        composable("onboarding") { OnboardingScreen { auth.finishOnboarding(); nav.navigate("signup") { popUpTo("onboarding") { inclusive = true } } } }
        composable("signin") { SignInScreen(auth, onSignedIn = { auth.markSignedIn() }, onSignUp = { nav.navigate("signup") }, onForgot = { nav.navigate("forgot") }) }
        composable("signup") { SignUpScreen(auth, app.currencies, onSignedIn = { auth.markSignedIn() }, onBack = { if (!nav.popBackStack()) nav.navigate("signin") }) }
        composable("forgot") { ForgotPasswordScreen(auth, onDone = { nav.popBackStack() }, onBack = { nav.popBackStack() }) }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)
private val LEFT = listOf(Tab("home", "Home", Icons.Filled.Home), Tab("transactions", "Transactions", Icons.Filled.SwapHoriz))
private val RIGHT = listOf(Tab("budget", "Budget", Icons.Filled.AccountBalanceWallet), Tab("reports", "Reports", Icons.Filled.BarChart), Tab("ai", "AI", Icons.Filled.AutoAwesome))
private val TAB_ROUTES = (LEFT + RIGHT).map { it.route }.toSet()

private fun NavHostController.goTab(route: String) = navigate(route) {
    popUpTo(graph.findStartDestination().id) { saveState = true }
    launchSingleTop = true; restoreState = true
}

@Composable
private fun MainNav(vm: AppViewModel, onSignedOut: () -> Unit) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val online by vm.online.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.events.collect { snack.showSnackbar(it) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            AnimatedVisibility(route in TAB_ROUTES) {
                Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp, shadowElevation = 6.dp) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                        LEFT.forEach { t -> TabItem(t, route == t.route, Modifier.weight(1f)) { nav.goTab(t.route) } }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            FilledIconButton(onClick = { nav.navigate("add/expense") }, modifier = Modifier.size(52.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                                Icon(Icons.Filled.Add, contentDescription = "Add transaction")
                            }
                        }
                        RIGHT.forEach { t -> TabItem(t, route == t.route, Modifier.weight(1f)) { nav.goTab(t.route) } }
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().statusBarsPadding()) {
            OfflineBanner(online, vm.pending.size)
            NavHost(nav, startDestination = "home", modifier = Modifier.weight(1f)) {
                composable("home") {
                    HomeScreen(vm, onAdd = { nav.navigate("add/$it") }, onOpenTx = { nav.navigate("tx/$it") }, onSeeAll = { nav.goTab("transactions") },
                        onNotifications = { nav.navigate("notifications") }, onProfile = { nav.navigate("profile") }, onAi = { nav.goTab("ai") }, onReports = { nav.goTab("reports") })
                }
                composable("transactions") { TransactionsScreen(vm, onOpen = { nav.navigate("tx/$it") }, onAdd = { nav.navigate("add/expense") }, onUpgrade = { nav.navigate("premium") }) }
                composable("budget") { BudgetScreen(vm, onUpgrade = { nav.navigate("premium") }) }
                composable("reports") { ReportsScreen(vm, onAdd = { nav.navigate("add/expense") }, onUpgrade = { nav.navigate("premium") }) }
                composable("ai") { AssistantScreen(vm) }
                composable("add/{type}", listOf(navArgument("type") { type = NavType.StringType })) { e ->
                    AddTransactionScreen(vm, null, e.arguments?.getString("type") ?: "expense", onClose = { nav.popBackStack() }, onUpgrade = { nav.navigate("premium") })
                }
                composable("edit/{id}", listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    AddTransactionScreen(vm, e.arguments?.getString("id"), "expense", onClose = { nav.popBackStack() }, onUpgrade = { nav.navigate("premium") })
                }
                composable("tx/{id}", listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    TransactionDetailScreen(vm, e.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() }, onEdit = { nav.navigate("edit/$it") })
                }
                composable("notifications") { NotificationsScreen(vm, onBack = { nav.popBackStack() }) }
                composable("profile") { ProfileScreen(vm, onBack = { nav.popBackStack() }, onPremium = { nav.navigate("premium") }, onSignedOut = onSignedOut) }
                composable("premium") { PremiumScreen(vm, onBack = { nav.popBackStack() }) }
            }
        }
    }
}

@Composable
private fun TabItem(tab: Tab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) { Icon(tab.icon, contentDescription = tab.label, tint = color) }
        Text(tab.label, style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
    }
}
