package com.spendly.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.spendly.app.ui.AppViewModel
import com.spendly.app.ui.components.*
import com.spendly.app.ui.theme.SpendlyColors

private val SUGGESTIONS = listOf("Where did I spend the most this month?", "How much did I spend on food?", "Compare my spending this month with last month.", "Am I staying within my budget?", "How can I reduce my spending?", "Give me a summary of my finances.")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssistantScreen(vm: AppViewModel) {
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(vm.chat.size, vm.chatBusy) { if (vm.chat.isNotEmpty()) listState.animateScrollToItem(vm.chat.size + (if (vm.chatBusy) 1 else 0) - 1) }
    fun send(text: String) { vm.sendChat(text); input = "" }
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader("AI Assistant", actions = { Icon(Icons.Filled.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 8.dp)) })
        if (vm.chat.isEmpty()) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(24.dp))
                Box(Modifier.size(84.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.SmartToy, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("What would you like to know?", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("I can help you understand your spending, find insights and give simple advice based on your transactions.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SUGGESTIONS.forEach { s -> SuggestionChip(onClick = { send(s) }, label = { Text(s) }, shape = RoundedCornerShape(20.dp)) }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.chat, key = { it.id }) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = if (m.fromUser) 16.dp else 4.dp, bottomEnd = if (m.fromUser) 4.dp else 16.dp),
                            color = when { m.fromUser -> MaterialTheme.colorScheme.primary; m.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f); else -> MaterialTheme.colorScheme.surfaceVariant },
                            modifier = Modifier.widthIn(max = 320.dp),
                        ) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                Text(m.text, style = MaterialTheme.typography.bodyMedium, color = if (m.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                                if (m.isError) TextButton(onClick = vm::retryChat, contentPadding = PaddingValues(0.dp)) { Text("Try again") }
                            }
                        }
                    }
                }
                if (vm.chatBusy) item(key = "typing") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp))
                        Text("Thinking…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        vm.aiRemaining?.let { Text("$it assistant messages left today", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp)) }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { if (it.length <= 1000) input = it }, Modifier.weight(1f), placeholder = { Text("Ask a question...") }, maxLines = 4, shape = RoundedCornerShape(24.dp),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = { send(input) }),
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { send(input) }, enabled = input.isNotBlank() && !vm.chatBusy, modifier = Modifier.size(48.dp)) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}
