package com.spendly.app.ui.screens

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.spendly.app.BuildConfig
import com.spendly.app.R
import com.spendly.app.ui.AuthViewModel
import com.spendly.app.ui.components.*
import com.spendly.app.ui.theme.SpendlyColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(SpendlyColors.Deep), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.s_mark), contentDescription = "Spendly logo", modifier = Modifier.size(120.dp))
            Spacer(Modifier.height(12.dp))
            Text("Spendly", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Know where your money goes.", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

private data class OnboardPage(val icon: ImageVector, val title: String, val body: String)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pages = listOf(
        OnboardPage(Icons.Filled.AccountBalanceWallet, "Track every naira, dollar or pound", "Log income and expenses in any currency. Everything is saved securely to your account."),
        OnboardPage(Icons.Filled.PieChart, "See where your money goes", "Clear reports and budgets built from your real transactions, so you always know where you stand."),
        OnboardPage(Icons.Filled.AutoAwesome, "Ask your AI assistant", "Get plain-language answers and practical tips based on your own spending, powered by Claude."),
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onFinish) { Text("Skip") } }
        HorizontalPager(pager, Modifier.weight(1f)) { i ->
            val p = pages[i]
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(140.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    Icon(p.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(64.dp))
                }
                Spacer(Modifier.height(32.dp))
                Text(p.title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(p.body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.Center) {
            repeat(pages.size) { i ->
                Box(Modifier.padding(4.dp).size(if (i == pager.currentPage) 10.dp else 8.dp).clip(CircleShape)
                    .background(if (i == pager.currentPage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline))
            }
        }
        val last = pager.currentPage == pages.size - 1
        PrimaryButton(if (last) "Get started" else "Next", onClick = { if (last) onFinish() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } })
    }
}

@Composable
private fun AuthHeader() {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.spendly_logo), contentDescription = "Spendly logo", modifier = Modifier.size(68.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.height(8.dp))
        Text("Spendly", style = MaterialTheme.typography.headlineMedium)
        Text("Know where your money goes.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun GoogleButton(vm: AuthViewModel, onSignedIn: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var working by remember { mutableStateOf(false) }
    OutlineButton(
        text = if (working) "Connecting…" else "Continue with Google", enabled = !working,
        icon = { Text("G", fontWeight = FontWeight.Bold, color = Color(0xFF4285F4), fontSize = 18.sp) },
        onClick = {
            if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isBlank()) { vm.googleFailed("Google sign-in isn't configured in this build yet."); return@OutlineButton }
            val activity = context as? Activity ?: return@OutlineButton
            working = true
            scope.launch {
                try {
                    val option = GetSignInWithGoogleOption.Builder(BuildConfig.GOOGLE_WEB_CLIENT_ID).build()
                    val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                    val cred = CredentialManager.create(activity).getCredential(activity, request).credential
                    if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        vm.googleSignedIn(GoogleIdTokenCredential.createFrom(cred.data).idToken, onSignedIn)
                    } else vm.googleFailed("Google sign-in returned an unsupported credential.")
                } catch (e: GetCredentialCancellationException) {
                    // user closed the sheet
                } catch (e: GetCredentialException) {
                    vm.googleFailed("Google sign-in failed. Please try again.")
                } catch (e: Exception) {
                    vm.googleFailed("Google sign-in failed. Please try again.")
                }
                working = false
            }
        },
    )
}

@Composable
private fun AuthScaffold(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 16.dp),
        content = content,
    )
}

@Composable
private fun MessageLine(error: String?, info: String?) {
    if (error != null) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
    if (info != null) Text(info, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
}

@Composable
fun SignInScreen(vm: AuthViewModel, onSignedIn: () -> Unit, onSignUp: () -> Unit, onForgot: () -> Unit) {
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    DisposableEffect(Unit) { vm.clearMessages(); onDispose { } }
    AuthScaffold {
        Spacer(Modifier.height(24.dp))
        AuthHeader()
        Spacer(Modifier.height(28.dp))
        Text("Welcome Back", style = MaterialTheme.typography.titleLarge)
        Text("Sign in to continue", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        SpendlyTextField(email, { email = it }, "Email", leading = Icons.Filled.Email, keyboardType = KeyboardType.Email)
        Spacer(Modifier.height(8.dp))
        SpendlyTextField(password, { password = it }, "Password", leading = Icons.Filled.Lock, isPassword = true, imeAction = ImeAction.Done, onDone = { vm.signIn(email, password, onSignedIn) })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onForgot) { Text("Forgot password?") } }
        MessageLine(vm.error, vm.info)
        PrimaryButton("Sign In", onClick = { vm.signIn(email, password, onSignedIn) }, loading = vm.busy)
        DividerWithText("or")
        GoogleButton(vm, onSignedIn)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text("Don't have an account?", style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onSignUp) { Text("Sign Up", fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun DividerWithText(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        HorizontalDivider(Modifier.weight(1f)); Text(text, Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); HorizontalDivider(Modifier.weight(1f))
    }
}

@Composable
fun SignUpScreen(vm: AuthViewModel, currencies: List<com.spendly.app.data.CurrencyDto>, onSignedIn: () -> Unit, onBack: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var currency by rememberSaveable { mutableStateOf(vm.defaultCurrency) }
    var picker by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { vm.clearMessages(); onDispose { } }
    AuthScaffold {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        Text("Create Account", style = MaterialTheme.typography.titleLarge)
        Text("Start your journey with Spendly", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        SpendlyTextField(name, { name = it }, "Full name", leading = Icons.Filled.Person)
        Spacer(Modifier.height(8.dp))
        SpendlyTextField(email, { email = it }, "Email", leading = Icons.Filled.Email, keyboardType = KeyboardType.Email)
        Spacer(Modifier.height(8.dp))
        SpendlyTextField(password, { password = it }, "Password", leading = Icons.Filled.Lock, isPassword = true)
        Spacer(Modifier.height(8.dp))
        SpendlyTextField(confirm, { confirm = it }, "Confirm password", leading = Icons.Filled.Lock, isPassword = true, imeAction = ImeAction.Done, onDone = { vm.signUp(name, email, password, confirm, currency, onSignedIn) })
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Preferred currency", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            CurrencyChip(currency, onClick = { picker = true })
        }
        MessageLine(vm.error, vm.info)
        Spacer(Modifier.height(4.dp))
        PrimaryButton("Sign Up", onClick = { vm.signUp(name, email, password, confirm, currency, onSignedIn) }, loading = vm.busy)
        DividerWithText("or")
        GoogleButton(vm, onSignedIn)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text("Already have an account?", style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onBack) { Text("Sign In", fontWeight = FontWeight.SemiBold) }
        }
    }
    if (picker) {
        val list = if (currencies.isEmpty()) listOf("USD", "NGN", "GBP", "EUR", "CAD", "AUD", "GHS", "KES", "ZAR", "INR").map { com.spendly.app.data.CurrencyDto(it, it) } else currencies
        CurrencyPickerDialog(list, currency, onSelect = { currency = it; picker = false }, onDismiss = { picker = false })
    }
}

@Composable
fun ForgotPasswordScreen(vm: AuthViewModel, onDone: () -> Unit, onBack: () -> Unit) {
    var email by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    DisposableEffect(Unit) { vm.clearMessages(); onDispose { } }
    AuthScaffold {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        Text("Reset password", style = MaterialTheme.typography.titleLarge)
        Text(
            if (vm.resetSent) "Enter the 6-digit code we emailed you and choose a new password." else "Enter your email and we'll send you a reset code.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        SpendlyTextField(email, { email = it }, "Email", leading = Icons.Filled.Email, keyboardType = KeyboardType.Email, enabled = !vm.resetSent)
        if (vm.resetSent) {
            Spacer(Modifier.height(8.dp))
            SpendlyTextField(code, { code = it.filter(Char::isDigit).take(6) }, "6-digit code", leading = Icons.Filled.Lock, keyboardType = KeyboardType.NumberPassword)
            Spacer(Modifier.height(8.dp))
            SpendlyTextField(password, { password = it }, "New password", leading = Icons.Filled.Lock, isPassword = true, imeAction = ImeAction.Done)
        }
        MessageLine(vm.error, vm.info)
        Spacer(Modifier.height(8.dp))
        if (!vm.resetSent) PrimaryButton("Send reset code", onClick = { vm.requestReset(email) }, loading = vm.busy)
        else {
            PrimaryButton("Update password", onClick = { vm.resetPassword(email, code, password, onDone) }, loading = vm.busy)
            TextButton(onClick = { vm.requestReset(email) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Send a new code") }
        }
    }
}
