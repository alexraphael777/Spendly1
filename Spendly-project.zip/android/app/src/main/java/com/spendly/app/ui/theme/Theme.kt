package com.spendly.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object SpendlyColors {
    val Primary = Color(0xFF0F7B54)
    val Deep = Color(0xFF053F2D)
    val DeepSoft = Color(0xFF0B5A40)
    val Mint = Color(0xFFE8F5EE)
    val Lime = Color(0xFF9FE08B)
    val Income = Color(0xFF16A34A)
    val Expense = Color(0xFFE5484D)
    val Warning = Color(0xFFF59E0B)
}

private val Light = lightColorScheme(
    primary = SpendlyColors.Primary, onPrimary = Color.White,
    primaryContainer = SpendlyColors.Mint, onPrimaryContainer = SpendlyColors.Deep,
    secondary = SpendlyColors.DeepSoft, onSecondary = Color.White,
    background = Color(0xFFF7FAF8), onBackground = Color(0xFF0F1F19),
    surface = Color.White, onSurface = Color(0xFF0F1F19),
    surfaceVariant = Color(0xFFF1F6F3), onSurfaceVariant = Color(0xFF5E6E66),
    outline = Color(0xFFCBD8D1), outlineVariant = Color(0xFFE4ECE7),
    error = SpendlyColors.Expense, onError = Color.White,
)

private val Dark = darkColorScheme(
    primary = Color(0xFF3FBF8A), onPrimary = Color(0xFF04271C),
    primaryContainer = Color(0xFF0E3A2B), onPrimaryContainer = Color(0xFFCFF3E1),
    secondary = Color(0xFF7ED3AC), onSecondary = Color(0xFF04271C),
    background = Color(0xFF0B1511), onBackground = Color(0xFFE6F0EB),
    surface = Color(0xFF121F19), onSurface = Color(0xFFE6F0EB),
    surfaceVariant = Color(0xFF172620), onSurfaceVariant = Color(0xFF9FB2A9),
    outline = Color(0xFF3A5247), outlineVariant = Color(0xFF1E2E27),
    error = Color(0xFFFF7A7A), onError = Color(0xFF3B0A0A),
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp), extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun SpendlyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = AppTypography, shapes = AppShapes, content = content,
    )
}
