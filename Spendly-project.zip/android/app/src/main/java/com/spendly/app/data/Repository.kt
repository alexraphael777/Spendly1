package com.spendly.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.io.IOException
import java.util.UUID

class AppError(message: String, val code: String = "UNKNOWN", val status: Int = 0, val isNetwork: Boolean = false) : Exception(message) {
    val isPremiumRequired: Boolean get() = code == "PREMIUM_REQUIRED"
}

sealed interface Loaded<out T> {
    val data: T
    data class Fresh<T>(override val data: T) : Loaded<T>
    /** Served from the offline cache because the network is unavailable. */
    data class Stale<T>(override val data: T) : Loaded<T>
}

class SpendlyRepository(
    private val api: SpendlyApi,
    private val session: SessionStore,
    private val cache: LocalCache,
    private val json: Json,
) {
    private val flushLock = Mutex()

    // ---------- plumbing ----------
    private suspend fun <T> call(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        Result.failure(toAppError(e))
    }

    private fun toAppError(e: Throwable): AppError = when (e) {
        is AppError -> e
        is HttpException -> {
            val body = runCatching { e.response()?.errorBody()?.string() }.getOrNull()
            val parsed = body?.let { runCatching { json.decodeFromString<ErrorEnvelope>(it) }.getOrNull() }
            AppError(parsed?.error?.message?.takeIf { it.isNotBlank() } ?: "Something went wrong (${e.code()}).", parsed?.error?.code ?: "HTTP_${e.code()}", e.code())
        }
        is IOException -> AppError("You appear to be offline. Check your connection and try again.", "NETWORK", isNetwork = true)
        else -> AppError("Something unexpected happened. Please try again.")
    }

    private suspend inline fun <reified T> cachedGet(key: String?, crossinline fetch: suspend () -> T): Result<Loaded<T>> {
        val fresh = call { fetch() }
        return fresh.fold(
            onSuccess = { value ->
                if (key != null) cache.write(key, json.encodeToString(value))
                Result.success<Loaded<T>>(Loaded.Fresh(value))
            },
            onFailure = { e ->
                val offline = (e as? AppError)?.isNetwork == true
                val stored = if (offline && key != null) cache.read(key)?.let { runCatching { json.decodeFromString<T>(it) }.getOrNull() } else null
                if (stored != null) Result.success<Loaded<T>>(Loaded.Stale(stored)) else Result.failure(e)
            },
        )
    }

    // ---------- auth ----------
    private fun saveAuth(r: AuthResponse): UserDto {
        session.save(r.accessToken, r.refreshToken)
        cache.write("user", json.encodeToString(r.user))
        return r.user
    }
    suspend fun signIn(email: String, password: String) = call { api.login(LoginRequest(email.trim(), password)) }.map { saveAuth(it) }
    suspend fun signUp(name: String, email: String, password: String) = call { api.register(RegisterRequest(name.trim(), email.trim(), password)) }.map { saveAuth(it) }
    suspend fun signInWithGoogle(idToken: String) = call { api.google(GoogleRequest(idToken)) }.map { saveAuth(it) }
    suspend fun requestPasswordReset(email: String) = call { api.forgotPassword(ForgotRequest(email.trim())) }
    suspend fun resetPassword(email: String, code: String, newPassword: String) = call { api.resetPassword(ResetRequest(email.trim(), code.trim(), newPassword)) }

    val hasSession: Boolean get() = session.hasSession
    fun cachedUser(): UserDto? = cache.read("user")?.let { runCatching { json.decodeFromString<UserDto>(it) }.getOrNull() }

    suspend fun me(): Result<Loaded<UserDto>> = cachedGet("user") { api.me() }
    suspend fun updateMe(req: UpdateMeRequest) = call { api.updateMe(req) }.onSuccess { cache.write("user", json.encodeToString(it)) }
    suspend fun changePassword(current: String?, new: String) = call { api.changePassword(ChangePasswordRequest(current, new)) }.map { session.save(it.accessToken, it.refreshToken) }
    suspend fun deleteAccount(password: String?) = call { api.deleteMe(DeleteMeRequest(password = password)) }.onSuccess { clearLocal() }

    suspend fun signOut() {
        session.refreshToken?.let { rt -> call { api.logout(RefreshRequest(rt)) } } // best effort
        clearLocal()
    }
    fun clearLocal() { session.clear(); cache.clearAll() }

    // ---------- reference data ----------
    suspend fun currencies() = cachedGet("currencies") { api.currencies().items }
    suspend fun categories() = cachedGet("categories") { api.categories().items }
    suspend fun createCategory(name: String, type: String) = call { api.createCategory(CategoryRequest(name, type)) }

    // ---------- transactions ----------
    suspend fun transactions(f: TxFilter, offset: Int = 0): Result<Loaded<TransactionPage>> {
        val simple = f.query.isBlank() && f.currency == null && f.from == null && f.to == null && offset == 0
        return cachedGet(if (simple) "tx_${f.type}_${f.categoryId}_${f.month}" else null) {
            api.transactions(q = f.query.trim().ifBlank { null }, type = f.type, categoryId = f.categoryId, month = f.month, from = f.from, to = f.to, currency = f.currency, limit = 50, offset = offset)
        }
    }
    suspend fun updateTransaction(id: String, req: TransactionRequest) = call { api.updateTransaction(id, req.copy(clientId = null)) }
    suspend fun deleteTransaction(id: String) = call { api.deleteTransaction(id) }

    /** Returns the saved transaction, or null when the device is offline and the entry was queued for sync. */
    suspend fun createTransaction(req: TransactionRequest): Result<TransactionDto?> {
        val withId = req.copy(clientId = req.clientId ?: UUID.randomUUID().toString())
        val r = call { api.createTransaction(withId) }
        val err = r.exceptionOrNull() as? AppError
        if (err?.isNetwork == true) {
            enqueue(withId)
            return Result.success(null)
        }
        return r
    }

    // Offline queue. Every queued item carries a clientId so the server can never create a duplicate on retry.
    private fun readQueue(): List<TransactionRequest> =
        cache.read(QUEUE)?.let { runCatching { json.decodeFromString(ListSerializer(TransactionRequest.serializer()), it) }.getOrNull() } ?: emptyList()
    private fun writeQueue(list: List<TransactionRequest>) {
        if (list.isEmpty()) cache.remove(QUEUE) else cache.write(QUEUE, json.encodeToString(ListSerializer(TransactionRequest.serializer()), list))
    }
    private fun enqueue(req: TransactionRequest) = writeQueue(readQueue() + req)
    fun pendingRequests(): List<TransactionRequest> = readQueue()

    /** Sends queued transactions. Returns how many were synced. Stops at the first network failure. */
    suspend fun flushPending(): Int = flushLock.withLock {
        var synced = 0
        for (req in readQueue()) {
            val r = call { api.createTransaction(req) }
            val err = r.exceptionOrNull() as? AppError
            when {
                r.isSuccess -> { synced++; writeQueue(readQueue().filter { it.clientId != req.clientId }) }
                err?.isNetwork == true || err?.status == 401 || err?.status == 429 || (err?.status ?: 0) >= 500 -> return@withLock synced
                else -> writeQueue(readQueue().filter { it.clientId != req.clientId }) // permanently rejected by validation
            }
        }
        synced
    }

    // ---------- budgets ----------
    suspend fun budgets(month: String) = cachedGet("budgets_$month") { api.budgets(month) }
    suspend fun createBudget(req: BudgetRequest) = call { api.createBudget(req) }
    suspend fun updateBudget(id: String, req: BudgetUpdate) = call { api.updateBudget(id, req) }
    suspend fun deleteBudget(id: String) = call { api.deleteBudget(id) }

    // ---------- reports ----------
    suspend fun summary(month: String) = cachedGet("summary_$month") { api.summary(month) }
    suspend fun report(month: String) = cachedGet("report_$month") { api.report(month) }

    // ---------- notifications / subscription / AI ----------
    suspend fun notifications() = cachedGet("notifications") { api.notifications() }
    suspend fun markAllRead() = call { api.markAllRead() }
    suspend fun markRead(id: String) = call { api.markRead(id) }
    suspend fun dismissNotification(id: String) = call { api.dismissNotification(id) }
    suspend fun subscription() = call { api.subscription() }
    suspend fun checkout() = call { api.checkout() }
    suspend fun chat(message: String, history: List<ChatTurn>) = call { api.chat(AiRequest(message, history)) }

    private companion object { const val QUEUE = "pending_transactions" }
}

data class TxFilter(
    val query: String = "", val type: String? = null, val categoryId: String? = null, val month: String? = null,
    val currency: String? = null, val from: String? = null, val to: String? = null,
) { val hasAdvanced: Boolean get() = currency != null || from != null || to != null }
