package com.spendly.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import com.spendly.app.core.Dates
import com.spendly.app.core.Money
import com.spendly.app.data.BudgetDto
import com.spendly.app.ui.AppViewModel
import com.spendly.app.ui.components.*
import com.spendly.app.ui.theme.SpendlyColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BudgetScreen(vm: AppViewModel, onUpgrade: () -> Unit) {
    var editing by remember { mutableStateOf<BudgetDto?>(null) }
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Budget", actions = {
            IconButton(onClick = { creating = true }) { Icon(Icons.Filled.Add, contentDescription = "Create budget") }
        })
        LoadView(vm.budgets, vm::loadBudgets) { b ->
            if (b.items.isEmpty()) {
                EmptyState(Icons.Filled.AccountBalanceWallet, "Create your first budget", "Set a monthly limit for a category and Spendly will track your progress from your real transactions.", actionLabel = "Create budget", onAction = { creating = true })
            } else {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                    SCard(Modifier.fillMaxWidth()) {
                        Text("Monthly Budget", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Money.format(b.totals.limit, b.currency), style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(12.dp))
                        Row {
                            Column(Modifier.weight(1f)) {
                                Text("Spent", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(Money.format(b.totals.spent, b.currency), style = MaterialTheme.typography.titleMedium, color = SpendlyColors.Expense)
                            }
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text(if (b.totals.remaining < 0) "Over by" else "Remaining", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(Money.format(kotlin.math.abs(b.totals.remaining), b.currency), style = MaterialTheme.typography.titleMedium, color = if (b.totals.remaining < 0) SpendlyColors.Expense else MaterialTheme.colorScheme.primary)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        SpendlyProgress(b.totals.percent, if (b.totals.percent >= 100) SpendlyColors.Expense else if (b.totals.percent >= 80) SpendlyColors.Warning else MaterialTheme.colorScheme.primary)
                        Text("${b.totals.percent}% used", style = MaterialTheme.typography.bodySmall, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
                    }
                    SectionTitle("Category Spending")
                    b.items.forEach { item ->
                        val color = statusColor(item.status, parseColor(item.category.color))
                        SCard(Modifier.fillMaxWidth().padding(bottom = 8.dp), onClick = { editing = item }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CategoryBadge(item.category, 36.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.category.name, style = MaterialTheme.typography.titleSmall)
                                    Text("${Money.format(item.spent, item.currency)} / ${Money.format(item.amount, item.currency)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("${item.percent}%", style = MaterialTheme.typography.labelLarge, color = color)
                            }
                            Spacer(Modifier.height(8.dp))
                            SpendlyProgress(item.percent, color)
                            if (item.status == "exceeded") Text("Over budget by ${Money.format(-item.remaining, item.currency)}", style = MaterialTheme.typography.bodySmall, color = SpendlyColors.Expense, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    b.items.firstOrNull { it.status == "warning" }?.let {
                        Surface(shape = RoundedCornerShape(14.dp), color = SpendlyColors.Warning.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Warning, null, tint = SpendlyColors.Warning); Spacer(Modifier.width(8.dp))
                                Text("You're approaching your ${it.category.name} budget.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
    if (creating || editing != null) BudgetDialog(vm, editing, onDismiss = { creating = false; editing = null }, onUpgrade = { creating = false; editing = null; onUpgrade() })
}

@Composable
private fun BudgetDialog(vm: AppViewModel, existing: BudgetDto?, onDismiss: () -> Unit, onUpgrade: () -> Unit) {
    val used = ((vm.budgets as? com.spendly.app.ui.Load.Ready)?.data?.items ?: emptyList()).map { it.category.id }.toSet()
    val options = vm.categories.filter { it.type == "expense" && it.id !in used }
    var categoryId by remember { mutableStateOf(existing?.category?.id ?: options.firstOrNull()?.id) }
    var amount by remember { mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var currency by remember { mutableStateOf(existing?.currency ?: vm.preferredCurrency) }
    var error by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    var pickCurrency by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (existing == null) "Create budget" else "Edit ${existing.category.name} budget") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (existing == null) {
                    if (options.isEmpty()) Text("Every expense category already has a budget.", style = MaterialTheme.typography.bodyMedium)
                    else Box {
                        OutlineButton(vm.categories.firstOrNull { it.id == categoryId }?.name ?: "Choose category", { menu = true })
                        DropdownMenu(menu, { menu = false }) {
                            options.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, leadingIcon = { CategoryBadge(c, 28.dp) }, onClick = { categoryId = c.id; menu = false }) }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SpendlyTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(16); error = null }, "Monthly limit", Modifier.weight(1f), keyboardType = KeyboardType.Decimal, prefix = Money.symbol(currency) + " ")
                    Spacer(Modifier.width(8.dp))
                    CurrencyChip(currency, { pickCurrency = true })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (existing != null) TextButton(onClick = { confirmDelete = true }) { Text("Delete budget", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !vm.busy && (existing != null || categoryId != null), onClick = {
                val amt = Money.parseAmount(amount)
                if (amt == null) error = "Enter an amount greater than zero"
                else vm.saveBudget(existing, categoryId, amt, currency, onDone = { vm.toast("Budget saved"); onDismiss() }, onError = { error = it })
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    if (pickCurrency) CurrencyPickerDialog(vm.currencies, currency, { currency = it; pickCurrency = false }, { pickCurrency = false })
    if (confirmDelete && existing != null) ConfirmDialog("Delete budget?", "Your transactions are not affected.", "Delete", destructive = true,
        onConfirm = { vm.deleteBudget(existing.id); confirmDelete = false; onDismiss() }, onDismiss = { confirmDelete = false })
}

@Composable
fun ReportsScreen(vm: AppViewModel, onAdd: () -> Unit, onUpgrade: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Reports")
        MonthStepper(vm.reportMonth, onPrev = { vm.shiftReportMonth(-1) }, onNext = if (vm.reportMonth < Dates.currentMonth()) ({ vm.shiftReportMonth(1) }) else null, modifier = Modifier.padding(horizontal = 8.dp))
        LoadView(vm.report, { vm.loadReport() }) { r ->
            if (!r.hasData) {
                EmptyState(Icons.Filled.BarChart, "No reports yet", "Add transactions to start seeing your financial reports.", actionLabel = "Add transaction", onAction = onAdd)
            } else Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                SCard(Modifier.fillMaxWidth()) {
                    Text("Monthly summary", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    SummaryLine("Income", Money.format(r.summary.income, r.currency), SpendlyColors.Income)
                    SummaryLine("Expenses", Money.format(r.summary.expenses, r.currency), SpendlyColors.Expense)
                    SummaryLine("Net", Money.format(r.summary.net, r.currency, signed = true), if (r.summary.net >= 0) SpendlyColors.Income else SpendlyColors.Expense)
                    r.summary.savingsRate?.let { SummaryLine("Savings rate", "$it%", MaterialTheme.colorScheme.onSurface) }
                    SummaryLine("Average daily spend", Money.format(r.summary.averageDailySpend, r.currency), MaterialTheme.colorScheme.onSurface)
                    SummaryLine("Transactions", r.summary.transactionCount.toString(), MaterialTheme.colorScheme.onSurface)
                }
                if (r.unconvertedCount > 0) Text("${r.unconvertedCount} transactions couldn't be converted to ${r.currency} and are left out.", style = MaterialTheme.typography.bodySmall, color = SpendlyColors.Warning, modifier = Modifier.padding(top = 6.dp))
                SectionTitle("Spending by Category")
                SCard(Modifier.fillMaxWidth()) {
                    if (r.spendingByCategory.isEmpty()) Text("No expenses this month.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else Row(verticalAlignment = Alignment.CenterVertically) {
                        DonutChart(r.spendingByCategory.map { it.amount.toFloat() to parseColor(it.color) }, centerTop = Money.format(r.summary.expenses, r.currency), centerBottom = "Total Spending")
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            r.spendingByCategory.take(6).forEach { c ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                    Box(Modifier.size(8.dp).androidxBackground(parseColor(c.color)))
                                    Spacer(Modifier.width(6.dp))
                                    Text(c.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                    Text("${c.percent.toInt()}%", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
                SectionTitle("Income vs Expenses")
                SCard(Modifier.fillMaxWidth()) { IncomeExpenseBars(r.trend.map { Triple(Dates.monthShort(it.month), it.income, it.expenses) }) }
                if (!r.premium.unlocked) Text("Free accounts see the last ${r.premium.trendMonths} months.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                if (r.budgetPerformance.isNotEmpty()) {
                    SectionTitle("Budget performance")
                    SCard(Modifier.fillMaxWidth()) {
                        r.budgetPerformance.forEach { b ->
                            Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(b.category.name, style = MaterialTheme.typography.titleSmall)
                                    SpendlyProgress(b.percent, statusColor(b.status, MaterialTheme.colorScheme.primary), Modifier.padding(top = 4.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Text("${b.percent}%", style = MaterialTheme.typography.labelLarge, color = statusColor(b.status, MaterialTheme.colorScheme.onSurface))
                            }
                        }
                    }
                }
                if (vm.reportMonth == Dates.currentMonth()) (vm.summary as? com.spendly.app.ui.Load.Ready)?.data?.insights?.takeIf { it.isNotEmpty() }?.let { ins ->
                    SectionTitle("Spending Insights")
                    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ins.forEach { Row { Icon(Icons.Filled.Lightbulb, null, tint = SpendlyColors.Warning, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(it.text, style = MaterialTheme.typography.bodyMedium) } }
                        }
                    }
                }
                SectionTitle("Advanced insights")
                if (r.premium.unlocked) {
                    r.premium.daily?.takeIf { it.isNotEmpty() }?.let { days ->
                        SCard(Modifier.fillMaxWidth()) {
                            Text("Daily spending", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            IncomeExpenseBars(days.takeLast(14).map { Triple(it.date.takeLast(2), 0.0, it.amount) }, expensesOnly = true)
                        }
                    }
                    r.premium.topExpenses?.takeIf { it.isNotEmpty() }?.let { top ->
                        SCard(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            Text("Largest expenses", style = MaterialTheme.typography.titleSmall)
                            top.forEach { TransactionRow(it, onClick = {}, showDate = true) }
                        }
                    }
                } else {
                    SCard(Modifier.fillMaxWidth(), onClick = onUpgrade) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lock, null, tint = SpendlyColors.Warning); Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Daily spending and largest expenses", style = MaterialTheme.typography.titleSmall)
                                Text("Unlock 12-month history and advanced reports with Premium.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            PremiumBadge()
                        }
                    }
                }
            }
        }
    }
}

private fun Modifier.androidxBackground(color: androidx.compose.ui.graphics.Color): Modifier =
    this.then(Modifier.background(color, androidx.compose.foundation.shape.CircleShape))

@Composable
private fun SummaryLine(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleSmall, color = color)
    }
}
