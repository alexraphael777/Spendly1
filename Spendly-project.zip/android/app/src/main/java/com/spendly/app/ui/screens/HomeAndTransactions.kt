package com.spendly.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.spendly.app.core.Dates
import com.spendly.app.core.Money
import com.spendly.app.data.TransactionDto
import com.spendly.app.data.TxFilter
import com.spendly.app.ui.AppViewModel
import com.spendly.app.ui.Load
import com.spendly.app.ui.components.*
import com.spendly.app.ui.theme.SpendlyColors
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    vm: AppViewModel, onAdd: (String) -> Unit, onOpenTx: (String) -> Unit, onSeeAll: () -> Unit,
    onNotifications: () -> Unit, onProfile: () -> Unit, onAi: () -> Unit, onReports: () -> Unit,
) {
    var hidden by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(Dates.greeting(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(vm.user?.name?.substringBefore(' ') ?: "", style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Dates.monthLabel(Dates.currentMonth()), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onNotifications) {
                BadgedBox(badge = { if (vm.unreadCount > 0) Badge { Text(if (vm.unreadCount > 9) "9+" else vm.unreadCount.toString()) } }) {
                    Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                }
            }
            Box(Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer).clickable(onClick = onProfile), contentAlignment = Alignment.Center) {
                Text((vm.user?.name?.firstOrNull() ?: 'S').uppercase(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
            }
        }
        Spacer(Modifier.height(12.dp))
        when (val s = vm.summary) {
            Load.Loading -> Box(Modifier.fillMaxWidth().height(240.dp)) { LoadingState() }
            is Load.Failed -> ErrorState(s.message, vm::retryAll)
            is Load.Ready -> {
                val d = s.data
                if (!d.hasData) {
                    EmptyState(Icons.Filled.Receipt, "No transactions yet.", "Add your first transaction to see your balance, spending and insights here.", actionLabel = "Add transaction", onAction = { onAdd("expense") })
                } else {
                    Surface(shape = RoundedCornerShape(22.dp), color = SpendlyColors.Deep, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Total Balance", Modifier.weight(1f), color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
                                IconButton(onClick = { hidden = !hidden }) {
                                    Icon(if (hidden) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = if (hidden) "Show balance" else "Hide balance", tint = Color.White)
                                }
                            }
                            Text(if (hidden) "••••••" else Money.format(d.balance, d.currency), color = Color.White, style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.height(14.dp))
                            Row {
                                Column(Modifier.weight(1f)) {
                                    Text("Income", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                                    Text(if (hidden) "••••" else Money.format(d.income, d.currency), color = SpendlyColors.Lime, style = MaterialTheme.typography.titleMedium)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Expenses", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                                    Text(if (hidden) "••••" else Money.format(d.expenses, d.currency), color = Color(0xFFFF8A8A), style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                    }
                    if (s.offline) Text("Showing saved data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                    d.progress?.let { p ->
                        Spacer(Modifier.height(12.dp))
                        SCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text("This Month", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${p.percent}% of ${if (p.basis == "budget") "budget" else "income"}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                            Text("${Money.format(p.spent, d.currency)} spent", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            SpendlyProgress(p.percent, if (p.percent >= 100) SpendlyColors.Expense else if (p.percent >= 80) SpendlyColors.Warning else MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickAction(Icons.Filled.Add, "Expense", Modifier.weight(1f)) { onAdd("expense") }
                        QuickAction(Icons.Filled.South, "Income", Modifier.weight(1f)) { onAdd("income") }
                        QuickAction(Icons.Filled.BarChart, "Reports", Modifier.weight(1f), onReports)
                        QuickAction(Icons.Filled.AutoAwesome, "Ask AI", Modifier.weight(1f), onAi)
                    }
                    if (d.insights.isNotEmpty()) {
                        SectionTitle("Insights")
                        d.insights.take(3).forEach { ins ->
                            SCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                Row(verticalAlignment = Alignment.Top) {
                                    Icon(if (ins.kind == "warning") Icons.Filled.Warning else if (ins.kind == "positive") Icons.Filled.TrendingDown else Icons.Filled.Lightbulb, contentDescription = null,
                                        tint = if (ins.kind == "warning") SpendlyColors.Warning else MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text(ins.text, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    if (d.categories.isNotEmpty()) {
                        SectionTitle("Top spending")
                        SCard(Modifier.fillMaxWidth()) {
                            d.categories.forEach { c ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CategoryBadge(c.icon, c.color, 32.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(c.name, style = MaterialTheme.typography.titleSmall)
                                        SpendlyProgress(c.percent.toInt(), parseColor(c.color), Modifier.padding(top = 4.dp))
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Text(Money.format(c.amount, d.currency), style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    SectionTitle("Recent Transactions", action = "See all", onAction = onSeeAll)
                    d.recent.forEach { TransactionRow(it, onClick = { onOpenTx(it.id) }, showDate = true) }
                }
            }
        }
    }
}

@Composable
private fun QuickAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 1)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionsScreen(vm: AppViewModel, onOpen: (String) -> Unit, onAdd: () -> Unit, onUpgrade: () -> Unit) {
    var query by rememberSaveable { mutableStateOf(vm.filter.query) }
    var showAdvanced by remember { mutableStateOf(false) }
    var monthMenu by remember { mutableStateOf(false) }
    var catMenu by remember { mutableStateOf(false) }
    LaunchedEffect(query) { if (query != vm.filter.query) { delay(350); vm.setFilter(vm.filter.copy(query = query)) } }
    val f = vm.filter
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Transactions")
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                query, { query = it }, Modifier.weight(1f), placeholder = { Text("Search transactions...") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) }, shape = RoundedCornerShape(14.dp),
                trailingIcon = if (query.isNotEmpty()) ({ IconButton({ query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Clear search") } }) else null,
            )
            Spacer(Modifier.width(8.dp))
            FilledTonalIconButton(onClick = { showAdvanced = true }) {
                BadgedBox(badge = { if (f.hasAdvanced) Badge() }) { Icon(Icons.Filled.FilterList, contentDescription = "Advanced filters") }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SelectChip("All", f.type == null) { vm.setFilter(f.copy(type = null)) }
            SelectChip("Income", f.type == "income") { vm.setFilter(f.copy(type = "income")) }
            SelectChip("Expenses", f.type == "expense") { vm.setFilter(f.copy(type = "expense")) }
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                AssistChip(onClick = { monthMenu = true }, label = { Text(f.month?.let { Dates.monthLabel(it) } ?: "All time") }, trailingIcon = { Icon(Icons.Filled.ExpandMore, null, Modifier.size(18.dp)) })
                DropdownMenu(monthMenu, { monthMenu = false }) {
                    DropdownMenuItem(text = { Text("All time") }, onClick = { monthMenu = false; vm.setFilter(f.copy(month = null)) })
                    (0..11).map { Dates.shiftMonth(Dates.currentMonth(), -it.toLong()) }.forEach { m ->
                        DropdownMenuItem(text = { Text(Dates.monthLabel(m)) }, onClick = { monthMenu = false; vm.setFilter(f.copy(month = m)) })
                    }
                }
            }
            Box {
                AssistChip(onClick = { catMenu = true }, label = { Text(vm.categories.firstOrNull { it.id == f.categoryId }?.name ?: "All Categories") }, trailingIcon = { Icon(Icons.Filled.ExpandMore, null, Modifier.size(18.dp)) })
                DropdownMenu(catMenu, { catMenu = false }) {
                    DropdownMenuItem(text = { Text("All Categories") }, onClick = { catMenu = false; vm.setFilter(f.copy(categoryId = null)) })
                    vm.categories.filter { f.type == null || it.type == f.type }.forEach { c ->
                        DropdownMenuItem(text = { Text(c.name) }, leadingIcon = { CategoryBadge(c, 28.dp) }, onClick = { catMenu = false; vm.setFilter(f.copy(categoryId = c.id)) })
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        when (val s = vm.txs) {
            Load.Loading -> LoadingState()
            is Load.Failed -> ErrorState(s.message, vm::loadTransactions)
            is Load.Ready -> {
                val all = vm.visibleTransactions()
                if (all.isEmpty()) {
                    val filtered = f.query.isNotBlank() || f.type != null || f.categoryId != null || f.hasAdvanced
                    EmptyState(Icons.Filled.Receipt, if (filtered) "No matching transactions" else "No transactions yet", if (filtered) "Try changing your search or filters." else "Your transactions will appear here.",
                        actionLabel = if (filtered) null else "Add transaction", onAction = if (filtered) null else onAdd)
                } else {
                    val grouped = all.groupBy { Dates.dayHeader(it.occurredAt) }
                    val serverCount = s.data.size
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
                        grouped.forEach { (day, list) ->
                            item(key = "h_$day") { Text(day, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp, bottom = 2.dp)) }
                            items(list, key = { it.id }) { tx -> TransactionRow(tx, onClick = { if (!tx.isPending) onOpen(tx.id) }) }
                        }
                        if (vm.txTotal > serverCount) item(key = "more") {
                            LaunchedEffect(serverCount) { vm.loadMoreTransactions() }
                            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp) }
                        }
                    }
                }
            }
        }
    }
    if (showAdvanced) AdvancedFilterDialog(vm, f, onApply = { vm.setFilter(it); showAdvanced = false }, onDismiss = { showAdvanced = false }, onUpgrade = { showAdvanced = false; onUpgrade() })
}

@Composable
private fun AdvancedFilterDialog(vm: AppViewModel, f: TxFilter, onApply: (TxFilter) -> Unit, onDismiss: () -> Unit, onUpgrade: () -> Unit) {
    if (!vm.isPremium) {
        AlertDialog(
            onDismissRequest = onDismiss, title = { Text("Advanced filters") },
            text = { Text("Filter by currency and custom date ranges with Spendly Premium.") },
            confirmButton = { TextButton(onClick = onUpgrade) { Text("See Premium") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Not now") } },
        )
        return
    }
    var currency by remember { mutableStateOf(f.currency) }
    var from by remember { mutableStateOf<java.time.LocalDate?>(f.from?.let { Dates.localDate(it) }) }
    var to by remember { mutableStateOf<java.time.LocalDate?>(f.to?.let { Dates.localDate(it) }) }
    var pickCurrency by remember { mutableStateOf(false) }
    var pickFrom by remember { mutableStateOf(false) }
    var pickTo by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Advanced filters") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlineButton("Currency: ${currency ?: "Any"}", { pickCurrency = true })
                OutlineButton("From: ${from?.toString() ?: "Any date"}", { pickFrom = true })
                OutlineButton("To: ${to?.toString() ?: "Any date"}", { pickTo = true })
                Text("A date range replaces the month filter.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val zone = java.time.ZoneId.systemDefault()
                onApply(f.copy(
                    currency = currency, month = if (from != null || to != null) null else f.month,
                    from = from?.atStartOfDay(zone)?.toInstant()?.toString(),
                    to = to?.plusDays(1)?.atStartOfDay(zone)?.toInstant()?.minusMillis(1)?.toString(),
                ))
            }) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = { onApply(f.copy(currency = null, from = null, to = null)) }) { Text("Clear") } },
    )
    if (pickCurrency) CurrencyPickerDialog(vm.currencies, currency ?: "", { currency = it; pickCurrency = false }, { pickCurrency = false })
    if (pickFrom) SimpleDatePicker(from, { from = it; pickFrom = false }, { pickFrom = false })
    if (pickTo) SimpleDatePicker(to, { to = it; pickTo = false }, { pickTo = false })
}

@Composable
fun TransactionDetailScreen(vm: AppViewModel, id: String, onBack: () -> Unit, onEdit: (String) -> Unit) {
    val tx = vm.findTransaction(id)
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Transaction", onBack = onBack)
        if (tx == null) {
            EmptyState(Icons.Filled.SearchOff, "Transaction not found", "It may have been deleted.", actionLabel = "Go back", onAction = onBack)
            return@Column
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            SCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CategoryBadge(tx.category, 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(tx.category.name, style = MaterialTheme.typography.titleMedium)
                        Text(if (tx.isIncome) "Income" else "Expense", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(Money.format(if (tx.isIncome) tx.amount else -tx.amount, tx.currency, signed = true), style = MaterialTheme.typography.headlineMedium, color = if (tx.isIncome) SpendlyColors.Income else SpendlyColors.Expense)
                Text(tx.currency, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
            SCard(Modifier.fillMaxWidth()) {
                DetailLine("Date", Dates.dayHeader(tx.occurredAt) + ", " + Dates.time(tx.occurredAt))
                DetailLine("Payment method", tx.paymentMethod?.replace('_', ' ')?.replaceFirstChar { it.uppercase() } ?: "Not set")
                DetailLine("Note", tx.description.ifBlank { "No note" })
            }
            Spacer(Modifier.height(20.dp))
            PrimaryButton("Edit", { onEdit(tx.id) })
            Spacer(Modifier.height(8.dp))
            OutlineButton("Delete", { confirm = true })
        }
    }
    if (confirm) ConfirmDialog("Delete transaction?", "This permanently removes it from your account and updates your budgets and reports.", "Delete", destructive = true,
        onConfirm = { confirm = false; vm.deleteTransaction(id) { vm.toast("Transaction deleted"); onBack() } }, onDismiss = { confirm = false })
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
