package com.spendly.app

import com.spendly.app.core.Dates
import com.spendly.app.core.Money
import com.spendly.app.data.*
import com.spendly.app.ui.AuthValidation
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.Locale

class MoneyTest {
    @Before fun locale() { Locale.setDefault(Locale.US) }

    @Test fun formatsWithCurrencySymbolsAndNeverHardcodesOneCurrency() {
        assertEquals("₦185,400", Money.format(185400.0, "NGN"))
        assertEquals("$4,500.50", Money.format(4500.5, "USD"))
        assertEquals("£12", Money.format(12.0, "GBP"))
        assertEquals("€9.99", Money.format(9.99, "EUR"))
        assertEquals("-₦4,500", Money.format(-4500.0, "NGN"))
        assertEquals("+₦250,000", Money.format(250000.0, "NGN", signed = true))
    }

    @Test fun unknownSymbolFallsBackToIsoCode() { assertEquals("CHF 12", Money.format(12.0, "CHF")) }

    @Test fun zeroDecimalCurrenciesHaveNoFraction() { assertEquals("¥1,500", Money.format(1500.0, "JPY")) }

    @Test fun parsesUserAmounts() {
        assertEquals(1250.5, Money.parseAmount("1,250.50")!!, 0.0)
        assertNull(Money.parseAmount(""))
        assertNull(Money.parseAmount("0"))
        assertNull(Money.parseAmount("-5"))
        assertNull(Money.parseAmount("abc"))
        assertNull(Money.parseAmount("1e400"))
    }
}

class ValidationTest {
    @Test fun email() {
        assertNull(AuthValidation.email("alex@example.com"))
        assertNotNull(AuthValidation.email("alex"))
        assertNotNull(AuthValidation.email("a@b"))
    }
    @Test fun password() {
        assertNull(AuthValidation.password("Passw0rdX"))
        assertNotNull(AuthValidation.password("short1"))
        assertNotNull(AuthValidation.password("onlyletters"))
        assertNotNull(AuthValidation.password("12345678"))
    }
    @Test fun name() { assertNull(AuthValidation.name("Alex")); assertNotNull(AuthValidation.name("  ")) }
}

class DatesTest {
    @Test fun shiftsMonthsAcrossYears() {
        assertEquals("2025-12", Dates.shiftMonth("2026-01", -1))
        assertEquals("2026-02", Dates.shiftMonth("2025-12", 2))
    }
}

/** Guards the contract with the backend: real response shapes must decode, unknown fields must be ignored. */
class ApiContractTest {
    private val json = Json { ignoreUnknownKeys = true; explicitNulls = false; encodeDefaults = true }

    @Test fun emptyAccountSummaryDecodesAndShowsNoData() {
        val s = json.decodeFromString<SummaryDto>("""{"month":"2026-10","currency":"NGN","hasData":false,"balance":0,"income":0,"expenses":0,"previousExpenses":0,"progress":null,"categories":[],"recent":[],"insights":[],"unconvertedCount":0,"ratesUpdatedAt":null}""")
        assertFalse(s.hasData); assertTrue(s.recent.isEmpty()); assertEquals(0.0, s.balance, 0.0)
    }

    @Test fun transactionDecodes() {
        val t = json.decodeFromString<TransactionDto>("""{"id":"1","clientId":"c","type":"expense","amount":4500.5,"currency":"NGN","category":{"id":"sys_expense_food","name":"Food","icon":"food","color":"#F59E0B","type":"expense"},"description":"Lunch","paymentMethod":null,"occurredAt":"2026-10-03T12:45:00.000Z","createdAt":"x","updatedAt":"y"}""")
        assertFalse(t.isIncome); assertFalse(t.isPending); assertEquals("Food", t.category.name)
    }

    @Test fun errorEnvelopeDecodes() {
        val e = json.decodeFromString<ErrorEnvelope>("""{"error":{"code":"PREMIUM_REQUIRED","message":"Advanced filters is a Premium feature."}}""")
        assertEquals("PREMIUM_REQUIRED", e.error.code)
        assertTrue(AppError("x", e.error.code).isPremiumRequired)
    }

    @Test fun budgetAndSubscriptionDecode() {
        val b = json.decodeFromString<BudgetsResponse>("""{"month":"2026-10","currency":"USD","items":[{"id":"b","category":{"id":"c","name":"Food"},"amount":100,"currency":"USD","period":"monthly","spent":85,"remaining":15,"percent":85,"status":"warning","unconverted":0}],"totals":{"limit":100,"spent":85,"remaining":15,"percent":85}}""")
        assertEquals("warning", b.items.single().status)
        val sub = json.decodeFromString<SubscriptionDto>("""{"plan":"premium","status":"active","currentPeriodEnd":null,"limits":{"customCategories":null,"budgets":null,"aiMessagesPerDay":100,"trendMonths":12,"advancedFilters":true,"advancedReports":true},"paymentsConfigured":false}""")
        assertTrue(sub.isPremium)
    }

    @Test fun requestsNeverContainUserIdOrSecrets() {
        val body = json.encodeToString(TransactionRequest.serializer(), TransactionRequest(type = "expense", amount = 5.0, currency = "USD", categoryId = "c", occurredAt = "2026-10-03T00:00:00Z"))
        assertFalse(body.contains("userId")); assertFalse(body.contains("apiKey"))
    }

    @Test fun txFilterAdvancedFlag() {
        assertFalse(TxFilter(month = "2026-10").hasAdvanced)
        assertTrue(TxFilter(currency = "USD").hasAdvanced)
    }
}
