# Spendly: Know where your money goes.

```
Android app (Kotlin + Compose)  ->  Spendly backend (Node + SQLite)  ->  Anthropic Claude
```
The Anthropic key lives only in the backend environment. The app never talks to Anthropic.

## 1. Run the backend
```
cd backend
cp .env.example .env      # fill JWT_SECRET and ANTHROPIC_API_KEY
npm install
npm test                  # 19 tests
node --env-file=.env src/server.js
```
Deploy anywhere that runs Node 22 or Docker (`backend/Dockerfile`), with HTTPS and a persistent disk
mounted at the `DATABASE_PATH` folder (Render, Railway, Fly.io, a VPS). SQLite is one-instance; move to Postgres before scaling out.

Environment variables: `JWT_SECRET`, `ANTHROPIC_API_KEY`, `GOOGLE_CLIENT_IDS`, `RESEND_API_KEY` (password reset emails), `MAIL_FROM`, `TRUST_PROXY=1`.
Models: `ANTHROPIC_MODEL_FREE` (default claude-haiku-4-5-20251001), `ANTHROPIC_MODEL_PREMIUM` (default claude-sonnet-5-5).

## 2. Build the APK
Option A, GitHub (no local setup): push this folder to a GitHub repo. In Settings > Secrets and variables > Actions > **Variables** add
`SPENDLY_API_URL` (your deployed backend, e.g. `https://spendly-api.onrender.com/`) and optionally `SPENDLY_GOOGLE_WEB_CLIENT_ID`.
Run the "Spendly CI" workflow and download `spendly-debug-apk` from the run's artifacts.

Option B, Android Studio: open `android/`, copy `local.properties.example` to `local.properties`, set `spendly.apiUrl`, press Run.
Release signing: set `spendly.keystore`, `spendly.keystorePassword`, `spendly.keyAlias`, `spendly.keyPassword`, then `gradle :app:assembleRelease`.

## 3. Google Sign-In
Google Cloud Console > create an OAuth **Web** client and an **Android** client (package `com.spendly.app`, your signing SHA-1).
Put the Web client ID in `spendly.googleWebClientId` (app) and `GOOGLE_CLIENT_IDS` (backend).

## 4. Payments
Premium is wired end to end (limits, gating, UI) but no payment provider is connected. `POST /api/subscription/checkout` returns 501.
Connect Google Play Billing or Stripe, verify receipts on the server, then set `subscriptions.plan='premium'`.
